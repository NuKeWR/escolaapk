#!/bin/bash
# ═══════════════════════════════════════════════════════════
# Escola Nuklear - Script de Build para APK Android
# ═══════════════════════════════════════════════════════════
#
# PRÉ-REQUISITOS:
#   - Ubuntu/Debian (WSL2 funciona)
#   - Python 3.8+
#   - Java JDK 17
#   - buildozer
#
# INSTALAR DEPENDÊNCIAS (Ubuntu/Debian):
#   sudo apt update
#   sudo apt install -y python3-pip build-essential git python3-dev \
#       ffmpeg libsdl2-dev libsdl2-image-dev libsdl2-mixer-dev \
#       libsdl2-ttf-dev libportmidi-dev libswscale-dev libavformat-dev \
#       libavcodec-dev zlib1g-dev libgstreamer1.0-dev \
#       gstreamer1.0-plugins-base gstreamer1.0-plugins-good \
#       openjdk-17-jdk autoconf libtool pkg-config \
#       libncurses5-dev libncursesw5-dev cmake unzip zip
#
#   pip install buildozer cython kivy
#
# ═══════════════════════════════════════════════════════════

echo "☢ ════════════════════════════════════════"
echo "    ESCOLA NUKLEAR — Build APK Android"
echo "☢ ════════════════════════════════════════"
echo ""

# Verificar se buildozer está instalado
if ! command -v buildozer &> /dev/null; then
    echo "❌ buildozer não encontrado!"
    echo "   Instale com: pip install buildozer"
    exit 1
fi

echo "✅ buildozer encontrado"

# Limpar builds anteriores
echo "🧹 Limpando builds anteriores..."
# buildozer android clean

# Build APK
echo "🔨 Construindo APK..."
echo "   Isso pode levar 10-30 minutos na primeira vez."
echo ""

buildozer -v android debug

echo ""
if [ -f bin/*.apk ]; then
    echo "✅ APK gerado com sucesso!"
    echo "   Arquivo: $(ls bin/*.apk)"
    echo ""
    echo "📱 Para instalar no dispositivo:"
    echo "   adb install -r $(ls bin/*.apk)"
else
    echo "❌ Falha ao gerar o APK. Verifique os logs acima."
fi
