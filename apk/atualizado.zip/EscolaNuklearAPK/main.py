"""
Escola Nuklear - App Android
=============================
Réplica completa do sistema web CT João Filho IA v3.2 para Android.
Reconhecimento facial via câmera/foto, gestão de alunos, presenças,
pagamentos, graduações, dashboard e relatórios.
Cores: Vermelho (#D32F2F) e Preto (#1A1A1A)
"""

import os
import json
import sqlite3
import shutil
from datetime import datetime, date
from functools import partial

from kivy.app import App
from kivy.lang import Builder
from kivy.clock import Clock
from kivy.uix.screenmanager import ScreenManager, Screen, SlideTransition
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.popup import Popup
from kivy.uix.image import Image as KivyImage
from kivy.uix.spinner import Spinner
from kivy.uix.togglebutton import ToggleButton
from kivy.uix.checkbox import CheckBox
from kivy.uix.modalview import ModalView
from kivy.properties import StringProperty, NumericProperty, ListProperty, BooleanProperty, ObjectProperty
from kivy.core.window import Window
from kivy.utils import platform
from kivy.metrics import dp, sp
from kivy.graphics import Color, Rectangle, RoundedRectangle, Line

# Tentar importar plyer (câmera e filechooser)
HAS_PLYER = False
try:
    from plyer import filechooser, camera
    HAS_PLYER = True
except Exception:
    pass

# ─── Paths ────────────────────────────────────────────────────────────
if platform == 'android':
    try:
        from android.storage import app_storage_path  # type: ignore
        APP_DIR = app_storage_path()
    except Exception:
        APP_DIR = os.path.join(os.path.expanduser('~'), '.escolanuklear')
else:
    APP_DIR = os.path.dirname(os.path.abspath(__file__))

DB_PATH = os.path.join(APP_DIR, "escola_nuklear.db")
FOTOS_DIR = os.path.join(APP_DIR, "fotos_alunos")
os.makedirs(FOTOS_DIR, exist_ok=True)

# ─── Database ─────────────────────────────────────────────────────────
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()
    c.execute("""
    CREATE TABLE IF NOT EXISTS alunos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        sexo TEXT DEFAULT '',
        data_nascimento TEXT DEFAULT '',
        faixa_atual TEXT DEFAULT '',
        tipo TEXT DEFAULT '',
        valor_mensalidade REAL DEFAULT 0,
        dia_vencimento INTEGER DEFAULT 5,
        telefone TEXT DEFAULT '',
        responsavel TEXT DEFAULT '',
        data_matricula TEXT DEFAULT '',
        turma TEXT DEFAULT '',
        horario TEXT DEFAULT '',
        modalidade TEXT DEFAULT '',
        observacoes TEXT DEFAULT '',
        ativo INTEGER DEFAULT 1,
        foto_path TEXT DEFAULT ''
    )""")
    c.execute("""
    CREATE TABLE IF NOT EXISTS pagamentos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        aluno_id INTEGER,
        data_pagamento TEXT,
        competencia TEXT,
        valor_pago REAL,
        forma_pagamento TEXT DEFAULT '',
        observacao TEXT DEFAULT '',
        FOREIGN KEY(aluno_id) REFERENCES alunos(id)
    )""")
    c.execute("""
    CREATE TABLE IF NOT EXISTS graduacoes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        aluno_id INTEGER,
        data_graduacao TEXT,
        faixa TEXT,
        observacao TEXT DEFAULT '',
        FOREIGN KEY(aluno_id) REFERENCES alunos(id)
    )""")
    c.execute("""
    CREATE TABLE IF NOT EXISTS presencas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        data TEXT,
        aluno TEXT
    )""")
    conn.commit()
    conn.close()

def status_aluno(aluno_id):
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT tipo FROM alunos WHERE id=?", (aluno_id,))
    aluno = c.fetchone()
    if not aluno:
        conn.close()
        return "⚠️ Não encontrado"
    tipo = aluno[0] or ""
    if tipo.lower() == "bolsista":
        conn.close()
        return "🟡 Bolsista"
    if tipo.lower() == "professor":
        conn.close()
        return "🔵 Isento"
    c.execute("SELECT competencia FROM pagamentos WHERE aluno_id=? ORDER BY competencia DESC LIMIT 1", (aluno_id,))
    ultimo = c.fetchone()
    conn.close()
    hoje = datetime.now()
    comp = f"{hoje.year}-{hoje.month:02d}"
    if not ultimo:
        return "🔴 Sem pagamento"
    if ultimo[0] >= comp:
        return "🟢 Em dia"
    return "🔴 Atrasado"

def calcular_meses_atraso(aluno_id):
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT competencia FROM pagamentos WHERE aluno_id=? ORDER BY competencia DESC LIMIT 1", (aluno_id,))
    u = c.fetchone()
    conn.close()
    hoje = datetime.now()
    comp = f"{hoje.year}-{hoje.month:02d}"
    if not u or u[0] >= comp:
        return 0
    ay, am = map(int, comp.split('-'))
    uy, um = map(int, u[0].split('-'))
    return (ay - uy) * 12 + (am - um)

def listar_horarios():
    conn = get_db()
    rows = conn.execute(
        "SELECT DISTINCT horario FROM alunos WHERE ativo=1 AND horario IS NOT NULL AND horario != '' ORDER BY horario"
    ).fetchall()
    conn.close()
    return [r[0] for r in rows]

# ─── KV Language ──────────────────────────────────────────────────────
KV = """
#:import dp kivy.metrics.dp
#:import sp kivy.metrics.sp

<NukLabel@Label>:
    color: 1, 1, 1, 1
    font_size: sp(14)
    text_size: self.width, None
    halign: 'left'
    size_hint_y: None
    height: self.texture_size[1] + dp(8)

<NukTitle@Label>:
    color: 1, 1, 1, 1
    font_size: sp(20)
    bold: True
    size_hint_y: None
    height: dp(40)

<NukButton@Button>:
    background_color: 0.827, 0.184, 0.184, 1
    color: 1, 1, 1, 1
    font_size: sp(14)
    bold: True
    size_hint_y: None
    height: dp(48)
    background_normal: ''

<NukButtonDark@Button>:
    background_color: 0.1, 0.1, 0.1, 1
    color: 1, 1, 1, 1
    font_size: sp(14)
    bold: True
    size_hint_y: None
    height: dp(48)
    background_normal: ''

<NukButtonGreen@Button>:
    background_color: 0.2, 0.7, 0.2, 1
    color: 1, 1, 1, 1
    font_size: sp(14)
    bold: True
    size_hint_y: None
    height: dp(48)
    background_normal: ''

<NukInput@TextInput>:
    multiline: False
    size_hint_y: None
    height: dp(44)
    font_size: sp(14)
    background_color: 0.15, 0.15, 0.15, 1
    foreground_color: 1, 1, 1, 1
    cursor_color: 0.827, 0.184, 0.184, 1
    hint_text_color: 0.5, 0.5, 0.5, 1
    padding: [dp(10), dp(10), dp(10), dp(10)]

<NukSpinner@Spinner>:
    size_hint_y: None
    height: dp(44)
    font_size: sp(14)
    background_color: 0.2, 0.2, 0.2, 1
    color: 1, 1, 1, 1
    background_normal: ''

<TopBar@BoxLayout>:
    size_hint_y: None
    height: dp(56)
    padding: dp(8)
    spacing: dp(8)
    canvas.before:
        Color:
            rgba: 0.827, 0.184, 0.184, 1
        Rectangle:
            pos: self.pos
            size: self.size
    NukButtonDark:
        text: '☰'
        size_hint_x: None
        width: dp(48)
        height: dp(40)
        on_release: app.toggle_menu()
    Label:
        text: root.title if hasattr(root, 'title') else 'Escola Nuklear'
        font_size: sp(18)
        bold: True
        color: 1, 1, 1, 1

<MenuItem@Button>:
    size_hint_y: None
    height: dp(50)
    font_size: sp(15)
    background_color: 0.12, 0.12, 0.12, 1
    background_normal: ''
    color: 1, 1, 1, 1
    halign: 'left'
    padding: [dp(16), 0]
    text_size: self.width - dp(32), None

<MenuPopup@Popup>:
    title: ''
    separator_height: 0
    size_hint: 0.75, 1
    pos_hint: {'x': 0}
    background_color: 0, 0, 0, 0.9
    background: ''
    auto_dismiss: True
    BoxLayout:
        orientation: 'vertical'
        padding: 0
        spacing: 0
        canvas.before:
            Color:
                rgba: 0.1, 0.1, 0.1, 1
            Rectangle:
                pos: self.pos
                size: self.size
        BoxLayout:
            size_hint_y: None
            height: dp(80)
            padding: dp(16)
            canvas.before:
                Color:
                    rgba: 0.827, 0.184, 0.184, 1
                Rectangle:
                    pos: self.pos
                    size: self.size
            Label:
                text: '☢ ESCOLA\\nNUKLEAR'
                font_size: sp(20)
                bold: True
                color: 1, 1, 1, 1
                halign: 'left'
                text_size: self.width, None
        ScrollView:
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                spacing: dp(1)
                MenuItem:
                    text: '📊  Dashboard'
                    on_release: app.go_screen('dashboard'); app.close_menu()
                MenuItem:
                    text: '👥  Alunos'
                    on_release: app.go_screen('alunos'); app.close_menu()
                MenuItem:
                    text: '➕  Cadastrar Aluno'
                    on_release: app.go_screen('cadastrar_aluno'); app.close_menu()
                MenuItem:
                    text: '📸  Reconhecimento Facial'
                    on_release: app.go_screen('reconhecimento'); app.close_menu()
                MenuItem:
                    text: '✅  Presenças'
                    on_release: app.go_screen('presencas'); app.close_menu()
                MenuItem:
                    text: '📈  Relatório Frequência'
                    on_release: app.go_screen('relatorio_frequencia'); app.close_menu()
                MenuItem:
                    text: '🔴  Inadimplentes'
                    on_release: app.go_screen('inadimplentes'); app.close_menu()
                MenuItem:
                    text: '💰  Histórico Financeiro'
                    on_release: app.go_screen('historico_financeiro'); app.close_menu()
                MenuItem:
                    text: '⚙️  Configurações'
                    on_release: app.go_screen('configuracoes'); app.close_menu()
                Widget:
                    size_hint_y: None
                    height: dp(20)
                Label:
                    text: 'v1.0 — Escola Nuklear'
                    font_size: sp(11)
                    color: 0.5, 0.5, 0.5, 1
                    size_hint_y: None
                    height: dp(30)

# ─── Tela Dashboard ────────────────────────────────────────────────
<DashboardScreen>:
    name: 'dashboard'
    BoxLayout:
        orientation: 'vertical'
        canvas.before:
            Color:
                rgba: 0.1, 0.1, 0.1, 1
            Rectangle:
                pos: self.pos
                size: self.size
        TopBar:
            title: '📊 Dashboard'
        ScrollView:
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(12)
                spacing: dp(10)
                id: dashboard_content

# ─── Tela Alunos ────────────────────────────────────────────────
<AlunosScreen>:
    name: 'alunos'
    BoxLayout:
        orientation: 'vertical'
        canvas.before:
            Color:
                rgba: 0.1, 0.1, 0.1, 1
            Rectangle:
                pos: self.pos
                size: self.size
        TopBar:
            title: '👥 Alunos'
        BoxLayout:
            size_hint_y: None
            height: dp(50)
            padding: dp(8)
            spacing: dp(8)
            NukInput:
                id: busca_aluno
                hint_text: '🔍 Buscar aluno...'
                on_text: root.filtrar(self.text)
            NukSpinner:
                id: filtro_horario
                text: 'Todos'
                values: ['Todos']
                size_hint_x: 0.4
                on_text: root.carregar()
        BoxLayout:
            size_hint_y: None
            height: dp(40)
            padding: [dp(8), 0]
            spacing: dp(8)
            ToggleButton:
                text: 'Ativos'
                group: 'filtro_ativo'
                state: 'down'
                size_hint_x: 0.33
                background_color: 0.2, 0.7, 0.2, 1 if self.state == 'down' else (0.3, 0.3, 0.3, 1)
                background_normal: ''
                color: 1,1,1,1
                font_size: sp(13)
                on_state: root.carregar()
                id: btn_ativos
            ToggleButton:
                text: 'Inativos'
                group: 'filtro_ativo'
                size_hint_x: 0.33
                background_color: 0.827, 0.184, 0.184, 1 if self.state == 'down' else (0.3, 0.3, 0.3, 1)
                background_normal: ''
                color: 1,1,1,1
                font_size: sp(13)
                on_state: root.carregar()
                id: btn_inativos
            ToggleButton:
                text: 'Todos'
                group: 'filtro_ativo'
                size_hint_x: 0.33
                background_color: 0.5, 0.5, 0.5, 1 if self.state == 'down' else (0.3, 0.3, 0.3, 1)
                background_normal: ''
                color: 1,1,1,1
                font_size: sp(13)
                on_state: root.carregar()
                id: btn_todos
        ScrollView:
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(8)
                spacing: dp(6)
                id: lista_alunos

# ─── Tela Cadastrar Aluno ───────────────────────────────────────
<CadastrarAlunoScreen>:
    name: 'cadastrar_aluno'
    BoxLayout:
        orientation: 'vertical'
        canvas.before:
            Color:
                rgba: 0.1, 0.1, 0.1, 1
            Rectangle:
                pos: self.pos
                size: self.size
        TopBar:
            title: '➕ Cadastrar Aluno'
        ScrollView:
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(16)
                spacing: dp(10)
                id: form_cadastro

# ─── Tela Editar Aluno ──────────────────────────────────────────
<EditarAlunoScreen>:
    name: 'editar_aluno'
    BoxLayout:
        orientation: 'vertical'
        canvas.before:
            Color:
                rgba: 0.1, 0.1, 0.1, 1
            Rectangle:
                pos: self.pos
                size: self.size
        TopBar:
            title: '✏️ Editar Aluno'
        ScrollView:
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(16)
                spacing: dp(10)
                id: form_editar

# ─── Tela Reconhecimento ────────────────────────────────────────
<ReconhecimentoScreen>:
    name: 'reconhecimento'
    BoxLayout:
        orientation: 'vertical'
        canvas.before:
            Color:
                rgba: 0.1, 0.1, 0.1, 1
            Rectangle:
                pos: self.pos
                size: self.size
        TopBar:
            title: '📸 Reconhecimento Facial'
        ScrollView:
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(16)
                spacing: dp(12)
                id: reconhecimento_content

# ─── Tela Presenças ─────────────────────────────────────────────
<PresencasScreen>:
    name: 'presencas'
    BoxLayout:
        orientation: 'vertical'
        canvas.before:
            Color:
                rgba: 0.1, 0.1, 0.1, 1
            Rectangle:
                pos: self.pos
                size: self.size
        TopBar:
            title: '✅ Presenças'
        BoxLayout:
            size_hint_y: None
            height: dp(50)
            padding: dp(8)
            spacing: dp(8)
            NukInput:
                id: data_presenca
                hint_text: 'Data (YYYY-MM-DD)'
                size_hint_x: 0.5
            NukSpinner:
                id: horario_presenca
                text: 'Todos'
                values: ['Todos']
                size_hint_x: 0.3
                on_text: root.carregar()
            NukButton:
                text: '🔄'
                size_hint_x: 0.2
                on_release: root.carregar()
        ScrollView:
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(8)
                spacing: dp(4)
                id: lista_presencas
        BoxLayout:
            size_hint_y: None
            height: dp(56)
            padding: dp(8)
            spacing: dp(8)
            NukButtonGreen:
                text: '💾 SALVAR PRESENÇAS'
                on_release: root.salvar_presencas()
            NukButton:
                text: '📋 MARCAR TODOS'
                size_hint_x: 0.4
                on_release: root.marcar_todos()

# ─── Tela Relatório Frequência ──────────────────────────────────
<RelatorioFrequenciaScreen>:
    name: 'relatorio_frequencia'
    BoxLayout:
        orientation: 'vertical'
        canvas.before:
            Color:
                rgba: 0.1, 0.1, 0.1, 1
            Rectangle:
                pos: self.pos
                size: self.size
        TopBar:
            title: '📈 Relatório Frequência'
        ScrollView:
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(12)
                spacing: dp(8)
                id: relatorio_content

# ─── Tela Pagamentos ────────────────────────────────────────────
<PagamentosScreen>:
    name: 'pagamentos'
    BoxLayout:
        orientation: 'vertical'
        canvas.before:
            Color:
                rgba: 0.1, 0.1, 0.1, 1
            Rectangle:
                pos: self.pos
                size: self.size
        TopBar:
            title: '💳 Pagamentos'
        ScrollView:
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(12)
                spacing: dp(8)
                id: pagamentos_content

# ─── Tela Inadimplentes ─────────────────────────────────────────
<InadimplentesScreen>:
    name: 'inadimplentes'
    BoxLayout:
        orientation: 'vertical'
        canvas.before:
            Color:
                rgba: 0.1, 0.1, 0.1, 1
            Rectangle:
                pos: self.pos
                size: self.size
        TopBar:
            title: '🔴 Inadimplentes'
        BoxLayout:
            size_hint_y: None
            height: dp(50)
            padding: dp(8)
            spacing: dp(8)
            NukSpinner:
                id: horario_inad
                text: 'Todos'
                values: ['Todos']
                on_text: root.carregar()
        ScrollView:
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(8)
                spacing: dp(6)
                id: lista_inadimplentes

# ─── Tela Histórico Financeiro ──────────────────────────────────
<HistoricoFinanceiroScreen>:
    name: 'historico_financeiro'
    BoxLayout:
        orientation: 'vertical'
        canvas.before:
            Color:
                rgba: 0.1, 0.1, 0.1, 1
            Rectangle:
                pos: self.pos
                size: self.size
        TopBar:
            title: '💰 Histórico Financeiro'
        ScrollView:
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(12)
                spacing: dp(8)
                id: historico_content

# ─── Tela Frequência do Aluno ───────────────────────────────────
<FrequenciaAlunoScreen>:
    name: 'frequencia_aluno'
    BoxLayout:
        orientation: 'vertical'
        canvas.before:
            Color:
                rgba: 0.1, 0.1, 0.1, 1
            Rectangle:
                pos: self.pos
                size: self.size
        TopBar:
            title: '📅 Frequência'
        ScrollView:
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(12)
                spacing: dp(6)
                id: freq_content

# ─── Tela Configurações ─────────────────────────────────────────
<ConfiguracoesScreen>:
    name: 'configuracoes'
    BoxLayout:
        orientation: 'vertical'
        canvas.before:
            Color:
                rgba: 0.1, 0.1, 0.1, 1
            Rectangle:
                pos: self.pos
                size: self.size
        TopBar:
            title: '⚙️ Configurações'
        ScrollView:
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: self.minimum_height
                padding: dp(16)
                spacing: dp(12)
                id: config_content

# ─── Root ────────────────────────────────────────────────────────
<RootWidget>:
    ScreenManager:
        id: sm
        DashboardScreen:
        AlunosScreen:
        CadastrarAlunoScreen:
        EditarAlunoScreen:
        ReconhecimentoScreen:
        PresencasScreen:
        RelatorioFrequenciaScreen:
        PagamentosScreen:
        InadimplentesScreen:
        HistoricoFinanceiroScreen:
        FrequenciaAlunoScreen:
        ConfiguracoesScreen:
"""

# ─── Widgets Auxiliares ───────────────────────────────────────────────
class CardWidget(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.size_hint_y = None
        self.padding = dp(12)
        self.spacing = dp(6)
        with self.canvas.before:
            Color(0.18, 0.18, 0.18, 1)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(10)])
        self.bind(pos=self._update_bg, size=self._update_bg)

    def _update_bg(self, *args):
        self._bg.pos = self.pos
        self._bg.size = self.size

class StatCard(BoxLayout):
    def __init__(self, titulo, valor, cor=(0.827, 0.184, 0.184, 1), **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.size_hint_y = None
        self.height = dp(80)
        self.padding = dp(10)
        with self.canvas.before:
            Color(*cor)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(8)])
        self.bind(pos=self._update, size=self._update)
        self.add_widget(Label(text=str(valor), font_size=sp(24), bold=True, color=(1,1,1,1),
                              size_hint_y=0.6))
        self.add_widget(Label(text=titulo, font_size=sp(11), color=(1,1,1,0.8),
                              size_hint_y=0.4))

    def _update(self, *args):
        self._bg.pos = self.pos
        self._bg.size = self.size


class AlunoCard(BoxLayout):
    def __init__(self, aluno_data, status_text, on_click=None, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'horizontal'
        self.size_hint_y = None
        self.height = dp(72)
        self.padding = dp(8)
        self.spacing = dp(10)
        with self.canvas.before:
            Color(0.18, 0.18, 0.18, 1)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(8)])
        self.bind(pos=self._update, size=self._update)

        # Info
        info_box = BoxLayout(orientation='vertical', size_hint_x=0.7)
        nome = aluno_data['nome'] if isinstance(aluno_data, dict) else aluno_data[1]
        turma = aluno_data.get('turma', '') if isinstance(aluno_data, dict) else (aluno_data[11] if len(aluno_data) > 11 else '')
        horario = aluno_data.get('horario', '') if isinstance(aluno_data, dict) else (aluno_data[12] if len(aluno_data) > 12 else '')

        info_box.add_widget(Label(text=nome, font_size=sp(15), bold=True,
                                  color=(1,1,1,1), halign='left', text_size=(None, None),
                                  size_hint_y=0.5))
        sub = f"{turma}  •  {horario}" if turma or horario else ""
        info_box.add_widget(Label(text=sub, font_size=sp(11),
                                  color=(0.7,0.7,0.7,1), halign='left', text_size=(None, None),
                                  size_hint_y=0.3))
        info_box.add_widget(Label(text=status_text, font_size=sp(11),
                                  color=(0.9,0.9,0.9,1), halign='left', text_size=(None, None),
                                  size_hint_y=0.2))
        self.add_widget(info_box)

        # Botão
        btn = Button(text='➤', size_hint_x=0.15, background_color=(0.827,0.184,0.184,1),
                     background_normal='', font_size=sp(18))
        if on_click:
            btn.bind(on_release=on_click)
        self.add_widget(btn)

    def _update(self, *args):
        self._bg.pos = self.pos
        self._bg.size = self.size


# ─── Screens ─────────────────────────────────────────────────────────
class DashboardScreen(Screen):
    def on_enter(self):
        self.carregar()

    def carregar(self):
        container = self.ids.dashboard_content
        container.clear_widgets()

        conn = get_db()
        c = conn.cursor()

        total_alunos = c.execute("SELECT COUNT(*) FROM alunos WHERE ativo=1").fetchone()[0]
        total_kids = c.execute("SELECT COUNT(*) FROM alunos WHERE turma='Kids' AND ativo=1").fetchone()[0]
        total_adultos = c.execute("SELECT COUNT(*) FROM alunos WHERE turma='Adulto' AND ativo=1").fetchone()[0]
        receita_prevista = c.execute("SELECT COALESCE(SUM(valor_mensalidade),0) FROM alunos WHERE ativo=1").fetchone()[0]

        hoje = datetime.now()
        comp = f"{hoje.year}-{hoje.month:02d}"
        recebido_mes = c.execute(
            "SELECT COALESCE(SUM(valor_pago),0) FROM pagamentos WHERE competencia=?", (comp,)
        ).fetchone()[0]
        em_aberto = receita_prevista - recebido_mes
        taxa = (recebido_mes / receita_prevista * 100) if receita_prevista > 0 else 0

        em_dia = atrasados = bolsistas = professores = 0
        for a in c.execute("SELECT id FROM alunos WHERE ativo=1").fetchall():
            s = status_aluno(a[0])
            if "Em dia" in s: em_dia += 1
            elif "Atrasado" in s or "Sem pagamento" in s: atrasados += 1
            elif "Bolsista" in s: bolsistas += 1
            elif "Isento" in s: professores += 1

        presentes_hoje = c.execute(
            "SELECT COUNT(*) FROM presencas WHERE data=?", (date.today().isoformat(),)
        ).fetchone()[0]

        por_horario = c.execute(
            "SELECT horario, COUNT(*) FROM alunos WHERE ativo=1 "
            "AND horario IS NOT NULL AND horario != '' GROUP BY horario ORDER BY horario"
        ).fetchall()

        mes_atual = f"{hoje.month:02d}"
        aniversariantes = c.execute(
            "SELECT id, nome, data_nascimento FROM alunos WHERE ativo=1 "
            "AND data_nascimento != '' AND substr(data_nascimento,6,2)=? "
            "ORDER BY substr(data_nascimento,9,2)", (mes_atual,)
        ).fetchall()

        conn.close()

        # Header
        container.add_widget(Label(text='☢ ESCOLA NUKLEAR', font_size=sp(22), bold=True,
                                   color=(0.827,0.184,0.184,1), size_hint_y=None, height=dp(40)))
        container.add_widget(Label(text=f'Dashboard — {hoje.strftime("%d/%m/%Y")}',
                                   font_size=sp(13), color=(0.7,0.7,0.7,1),
                                   size_hint_y=None, height=dp(24)))

        # Stats row 1
        row1 = GridLayout(cols=3, size_hint_y=None, height=dp(85), spacing=dp(8))
        row1.add_widget(StatCard('Total Alunos', total_alunos))
        row1.add_widget(StatCard('Kids', total_kids, cor=(0.2,0.6,0.9,1)))
        row1.add_widget(StatCard('Adultos', total_adultos, cor=(0.1,0.1,0.1,1)))
        container.add_widget(row1)

        # Stats row 2
        row2 = GridLayout(cols=2, size_hint_y=None, height=dp(85), spacing=dp(8))
        row2.add_widget(StatCard('Presentes Hoje', presentes_hoje, cor=(0.2,0.7,0.2,1)))
        row2.add_widget(StatCard('Inadimplentes', atrasados, cor=(0.8,0.2,0.2,1)))
        container.add_widget(row2)

        # Financeiro
        card_fin = CardWidget()
        card_fin.add_widget(Label(text='💰 FINANCEIRO DO MÊS', font_size=sp(16), bold=True,
                                  color=(0.827,0.184,0.184,1), size_hint_y=None, height=dp(30)))
        card_fin.add_widget(Label(text=f'Receita Prevista: R$ {receita_prevista:.2f}',
                                  font_size=sp(13), color=(1,1,1,1), size_hint_y=None, height=dp(22),
                                  halign='left', text_size=(None, None)))
        card_fin.add_widget(Label(text=f'Recebido: R$ {recebido_mes:.2f}',
                                  font_size=sp(13), color=(0.2,0.8,0.2,1), size_hint_y=None, height=dp(22),
                                  halign='left', text_size=(None, None)))
        card_fin.add_widget(Label(text=f'Em Aberto: R$ {em_aberto:.2f}',
                                  font_size=sp(13), color=(1,0.3,0.3,1), size_hint_y=None, height=dp(22),
                                  halign='left', text_size=(None, None)))
        card_fin.add_widget(Label(text=f'Taxa Adimplência: {taxa:.1f}%',
                                  font_size=sp(13), color=(1,1,0.5,1), size_hint_y=None, height=dp(22),
                                  halign='left', text_size=(None, None)))
        card_fin.height = dp(160)
        container.add_widget(card_fin)

        # Status
        card_st = CardWidget()
        card_st.add_widget(Label(text='📊 STATUS DOS ALUNOS', font_size=sp(16), bold=True,
                                 color=(0.827,0.184,0.184,1), size_hint_y=None, height=dp(30)))
        status_data = [
            (f'🟢 Em dia: {em_dia}', (0.2,0.8,0.2,1)),
            (f'🔴 Atrasados: {atrasados}', (1,0.3,0.3,1)),
            (f'🟡 Bolsistas: {bolsistas}', (1,0.8,0.2,1)),
            (f'🔵 Professores/Isentos: {professores}', (0.3,0.5,1,1)),
        ]
        for txt, cor in status_data:
            card_st.add_widget(Label(text=txt, font_size=sp(13), color=cor,
                                     size_hint_y=None, height=dp(22), halign='left',
                                     text_size=(None, None)))
        card_st.height = dp(160)
        container.add_widget(card_st)

        # Por horário
        if por_horario:
            card_h = CardWidget()
            card_h.add_widget(Label(text='🕐 ALUNOS POR HORÁRIO', font_size=sp(16), bold=True,
                                    color=(0.827,0.184,0.184,1), size_hint_y=None, height=dp(30)))
            for h in por_horario:
                card_h.add_widget(Label(text=f'{h[0]}: {h[1]} alunos', font_size=sp(13),
                                        color=(1,1,1,1), size_hint_y=None, height=dp(22),
                                        halign='left', text_size=(None, None)))
            card_h.height = dp(30 + len(por_horario) * 24 + 20)
            container.add_widget(card_h)

        # Aniversariantes
        if aniversariantes:
            card_an = CardWidget()
            card_an.add_widget(Label(text=f'🎂 ANIVERSARIANTES DE {hoje.strftime("%B").upper()}',
                                     font_size=sp(16), bold=True,
                                     color=(0.827,0.184,0.184,1), size_hint_y=None, height=dp(30)))
            for a in aniversariantes:
                dn = a[2] if a[2] else ''
                card_an.add_widget(Label(text=f'{a[1]} — {dn}', font_size=sp(13),
                                         color=(1,1,1,1), size_hint_y=None, height=dp(22),
                                         halign='left', text_size=(None, None)))
            card_an.height = dp(30 + len(aniversariantes) * 24 + 20)
            container.add_widget(card_an)

        # Spacer
        container.add_widget(Widget(size_hint_y=None, height=dp(20)))


class AlunosScreen(Screen):
    _all_alunos = []

    def on_enter(self):
        # Atualizar horários no spinner
        horarios = ['Todos'] + listar_horarios()
        self.ids.filtro_horario.values = horarios
        self.carregar()

    def carregar(self, *args):
        container = self.ids.lista_alunos
        container.clear_widgets()

        horario = self.ids.filtro_horario.text
        # Determinar filtro ativo
        ativo_filter = 1
        if self.ids.btn_inativos.state == 'down':
            ativo_filter = 0
        elif self.ids.btn_todos.state == 'down':
            ativo_filter = -1

        conn = get_db()
        if ativo_filter == -1:
            if horario and horario != 'Todos':
                rows = conn.execute("SELECT * FROM alunos WHERE horario=? ORDER BY nome", (horario,)).fetchall()
            else:
                rows = conn.execute("SELECT * FROM alunos ORDER BY nome").fetchall()
        else:
            if horario and horario != 'Todos':
                rows = conn.execute("SELECT * FROM alunos WHERE ativo=? AND horario=? ORDER BY nome",
                                    (ativo_filter, horario)).fetchall()
            else:
                rows = conn.execute("SELECT * FROM alunos WHERE ativo=? ORDER BY nome",
                                    (ativo_filter,)).fetchall()
        conn.close()

        self._all_alunos = rows

        # Header
        container.add_widget(Label(text=f'{len(rows)} aluno(s)', font_size=sp(12),
                                   color=(0.6,0.6,0.6,1), size_hint_y=None, height=dp(24)))

        for a in rows:
            aid = a[0]
            st = status_aluno(aid)
            card = AlunoCard(
                aluno_data={'nome': a[1], 'turma': a[11] if len(a) > 11 else '',
                           'horario': a[12] if len(a) > 12 else ''},
                status_text=st,
                on_click=partial(self.abrir_aluno, aid)
            )
            container.add_widget(card)

    def filtrar(self, texto):
        container = self.ids.lista_alunos
        container.clear_widgets()
        texto = texto.lower()
        filtrados = [a for a in self._all_alunos if texto in a[1].lower()]
        container.add_widget(Label(text=f'{len(filtrados)} aluno(s)', font_size=sp(12),
                                   color=(0.6,0.6,0.6,1), size_hint_y=None, height=dp(24)))
        for a in filtrados:
            aid = a[0]
            st = status_aluno(aid)
            card = AlunoCard(
                aluno_data={'nome': a[1], 'turma': a[11] if len(a) > 11 else '',
                           'horario': a[12] if len(a) > 12 else ''},
                status_text=st,
                on_click=partial(self.abrir_aluno, aid)
            )
            container.add_widget(card)

    def abrir_aluno(self, aid, *args):
        app = App.get_running_app()
        screen = app.root.ids.sm.get_screen('editar_aluno')
        screen.aluno_id = aid
        app.go_screen('editar_aluno')


class CadastrarAlunoScreen(Screen):
    foto_selecionada = StringProperty('')

    def on_enter(self):
        self.build_form()

    def build_form(self):
        container = self.ids.form_cadastro
        container.clear_widgets()
        self.foto_selecionada = ''

        self._inputs = {}

        campos = [
            ('nome', 'Nome completo *', ''),
            ('sexo', 'Sexo', 'spinner:M,F'),
            ('data_nascimento', 'Data Nascimento (YYYY-MM-DD)', ''),
            ('faixa', 'Faixa Atual', ''),
            ('tipo', 'Tipo', 'spinner:Aluno,Bolsista,Professor'),
            ('valor', 'Valor Mensalidade', '0'),
            ('dia_vencimento', 'Dia Vencimento', '5'),
            ('telefone', 'Telefone', ''),
            ('responsavel', 'Responsável', ''),
            ('turma', 'Turma', 'spinner:Kids,Adulto'),
            ('horario', 'Horário', ''),
            ('modalidade', 'Modalidade', ''),
            ('observacoes', 'Observações', ''),
        ]

        # Foto
        container.add_widget(Label(text='📸 FOTO DO ALUNO', font_size=sp(16), bold=True,
                                   color=(0.827,0.184,0.184,1), size_hint_y=None, height=dp(30)))
        foto_row = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        btn_camera = Button(text='📷 Câmera', background_color=(0.827,0.184,0.184,1),
                           background_normal='', color=(1,1,1,1), font_size=sp(13))
        btn_camera.bind(on_release=self.tirar_foto)
        btn_galeria = Button(text='🖼 Galeria', background_color=(0.1,0.1,0.1,1),
                            background_normal='', color=(1,1,1,1), font_size=sp(13))
        btn_galeria.bind(on_release=self.escolher_foto)
        foto_row.add_widget(btn_camera)
        foto_row.add_widget(btn_galeria)
        container.add_widget(foto_row)

        self._foto_label = Label(text='Nenhuma foto selecionada', font_size=sp(11),
                                color=(0.5,0.5,0.5,1), size_hint_y=None, height=dp(20))
        container.add_widget(self._foto_label)

        for key, label, default in campos:
            container.add_widget(Label(text=label, font_size=sp(12), color=(0.7,0.7,0.7,1),
                                       size_hint_y=None, height=dp(20), halign='left',
                                       text_size=(None, None)))
            if default.startswith('spinner:'):
                values = default.replace('spinner:', '').split(',')
                widget = Spinner(text=values[0], values=values,
                               size_hint_y=None, height=dp(44), font_size=sp(14),
                               background_color=(0.2,0.2,0.2,1), color=(1,1,1,1),
                               background_normal='')
                self._inputs[key] = widget
            else:
                widget = TextInput(text=default, multiline=False,
                                  size_hint_y=None, height=dp(44), font_size=sp(14),
                                  background_color=(0.15,0.15,0.15,1),
                                  foreground_color=(1,1,1,1),
                                  cursor_color=(0.827,0.184,0.184,1),
                                  hint_text_color=(0.5,0.5,0.5,1),
                                  padding=[dp(10), dp(10), dp(10), dp(10)])
                self._inputs[key] = widget
            container.add_widget(widget)

        # Botão salvar
        btn_salvar = Button(text='💾 CADASTRAR ALUNO', size_hint_y=None, height=dp(54),
                           background_color=(0.2,0.7,0.2,1), background_normal='',
                           color=(1,1,1,1), font_size=sp(16), bold=True)
        btn_salvar.bind(on_release=self.salvar)
        container.add_widget(Widget(size_hint_y=None, height=dp(12)))
        container.add_widget(btn_salvar)
        container.add_widget(Widget(size_hint_y=None, height=dp(20)))

    def tirar_foto(self, *args):
        if platform == 'android':
            try:
                from android.permissions import request_permissions, Permission  # type: ignore
                request_permissions([Permission.CAMERA, Permission.WRITE_EXTERNAL_STORAGE])
            except:
                pass
        if HAS_PLYER:
            try:
                filepath = os.path.join(FOTOS_DIR, f"temp_cadastro_{datetime.now().strftime('%Y%m%d%H%M%S')}.jpg")
                camera.take_picture(filename=filepath, on_complete=self._on_foto_tirada)
            except Exception as e:
                self._show_msg(f"Erro câmera: {e}")
        else:
            self._show_msg("Câmera não disponível neste dispositivo")

    def _on_foto_tirada(self, filepath):
        if filepath and os.path.exists(filepath):
            self.foto_selecionada = filepath
            self._foto_label.text = f'✅ Foto: {os.path.basename(filepath)}'

    def escolher_foto(self, *args):
        if HAS_PLYER:
            try:
                filechooser.open_file(on_selection=self._on_foto_escolhida,
                                     filters=["*.jpg", "*.jpeg", "*.png"])
            except Exception as e:
                self._show_msg(f"Erro: {e}")
        else:
            self._show_msg("Seletor de arquivos não disponível")

    def _on_foto_escolhida(self, selection):
        if selection:
            self.foto_selecionada = selection[0]
            self._foto_label.text = f'✅ Foto: {os.path.basename(selection[0])}'

    def salvar(self, *args):
        nome = self._get_val('nome')
        if not nome:
            self._show_msg('Nome é obrigatório!')
            return

        foto_final = ''
        if self.foto_selecionada and os.path.exists(self.foto_selecionada):
            ext = os.path.splitext(self.foto_selecionada)[1]
            foto_nome = f"{nome.replace(' ', '_')}_{datetime.now().strftime('%Y%m%d%H%M%S')}{ext}"
            foto_final = os.path.join(FOTOS_DIR, foto_nome)
            shutil.copy2(self.foto_selecionada, foto_final)

        conn = get_db()
        conn.execute("""
            INSERT INTO alunos (nome,sexo,data_nascimento,faixa_atual,tipo,valor_mensalidade,
            dia_vencimento,telefone,responsavel,data_matricula,turma,horario,modalidade,observacoes,ativo,foto_path)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            nome, self._get_val('sexo'), self._get_val('data_nascimento'),
            self._get_val('faixa'), self._get_val('tipo'),
            float(self._get_val('valor') or 0),
            int(self._get_val('dia_vencimento') or 5),
            self._get_val('telefone'), self._get_val('responsavel'),
            datetime.now().strftime('%Y-%m-%d'),
            self._get_val('turma'), self._get_val('horario'),
            self._get_val('modalidade'), self._get_val('observacoes'),
            1, foto_final
        ))
        conn.commit()
        conn.close()
        self._show_msg(f'✅ {nome} cadastrado!')
        App.get_running_app().go_screen('alunos')

    def _get_val(self, key):
        w = self._inputs.get(key)
        if w is None:
            return ''
        if isinstance(w, Spinner):
            return w.text
        return w.text.strip()

    def _show_msg(self, msg):
        popup = Popup(title='Aviso', content=Label(text=msg, color=(1,1,1,1)),
                     size_hint=(0.8, 0.3), background_color=(0.1,0.1,0.1,0.95))
        popup.open()


class EditarAlunoScreen(Screen):
    aluno_id = NumericProperty(0)

    def on_enter(self):
        self.build_form()

    def build_form(self):
        container = self.ids.form_editar
        container.clear_widgets()

        if not self.aluno_id:
            return

        conn = get_db()
        a = conn.execute("SELECT * FROM alunos WHERE id=?", (self.aluno_id,)).fetchone()
        graduacoes = conn.execute(
            "SELECT * FROM graduacoes WHERE aluno_id=? ORDER BY data_graduacao DESC",
            (self.aluno_id,)
        ).fetchall()
        conn.close()

        if not a:
            container.add_widget(Label(text='Aluno não encontrado', color=(1,0,0,1),
                                       size_hint_y=None, height=dp(40)))
            return

        self._inputs = {}

        # Nome e status
        st = status_aluno(self.aluno_id)
        container.add_widget(Label(text=f'{a[1]}', font_size=sp(20), bold=True,
                                   color=(0.827,0.184,0.184,1), size_hint_y=None, height=dp(36)))
        container.add_widget(Label(text=f'Status: {st}', font_size=sp(14),
                                   color=(1,1,1,1), size_hint_y=None, height=dp(24)))

        campos = [
            ('nome', 'Nome', a[1]),
            ('sexo', 'Sexo', a[2] or '', 'spinner:M,F'),
            ('data_nascimento', 'Data Nascimento', a[3] or ''),
            ('faixa', 'Faixa Atual', a[4] or ''),
            ('tipo', 'Tipo', a[5] or '', 'spinner:Aluno,Bolsista,Professor'),
            ('valor', 'Valor Mensalidade', str(a[6] or 0)),
            ('dia_vencimento', 'Dia Vencimento', str(a[7] or 5)),
            ('telefone', 'Telefone', a[8] or ''),
            ('responsavel', 'Responsável', a[9] or ''),
            ('data_matricula', 'Data Matrícula', a[10] or ''),
            ('turma', 'Turma', a[11] or '', 'spinner:Kids,Adulto'),
            ('horario', 'Horário', a[12] or ''),
            ('modalidade', 'Modalidade', a[13] or ''),
            ('observacoes', 'Observações', a[14] or ''),
        ]

        for item in campos:
            key, label, val = item[0], item[1], item[2]
            tipo = item[3] if len(item) > 3 else ''

            container.add_widget(Label(text=label, font_size=sp(12), color=(0.7,0.7,0.7,1),
                                       size_hint_y=None, height=dp(20), halign='left',
                                       text_size=(None, None)))
            if tipo.startswith('spinner:'):
                values = tipo.replace('spinner:', '').split(',')
                widget = Spinner(text=val if val in values else values[0], values=values,
                               size_hint_y=None, height=dp(44), font_size=sp(14),
                               background_color=(0.2,0.2,0.2,1), color=(1,1,1,1),
                               background_normal='')
            else:
                widget = TextInput(text=val, multiline=False,
                                  size_hint_y=None, height=dp(44), font_size=sp(14),
                                  background_color=(0.15,0.15,0.15,1),
                                  foreground_color=(1,1,1,1),
                                  cursor_color=(0.827,0.184,0.184,1),
                                  padding=[dp(10), dp(10), dp(10), dp(10)])
            self._inputs[key] = widget
            container.add_widget(widget)

        # Ativo checkbox
        ativo_row = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(8))
        ativo_row.add_widget(Label(text='Ativo:', color=(1,1,1,1), size_hint_x=0.3,
                                   font_size=sp(14)))
        self._ativo_check = CheckBox(active=bool(a[15]), size_hint_x=0.2,
                                     color=(0.827,0.184,0.184,1))
        ativo_row.add_widget(self._ativo_check)
        ativo_row.add_widget(Widget(size_hint_x=0.5))
        container.add_widget(ativo_row)

        # Botões de ação
        btn_row = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        btn_salvar = Button(text='💾 SALVAR', background_color=(0.2,0.7,0.2,1),
                           background_normal='', color=(1,1,1,1), font_size=sp(14))
        btn_salvar.bind(on_release=self.salvar)
        btn_row.add_widget(btn_salvar)

        btn_pag = Button(text='💳 PAGAMENTOS', background_color=(0.2,0.5,0.8,1),
                        background_normal='', color=(1,1,1,1), font_size=sp(14))
        btn_pag.bind(on_release=self.abrir_pagamentos)
        btn_row.add_widget(btn_pag)
        container.add_widget(btn_row)

        btn_row2 = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        btn_freq = Button(text='📅 FREQUÊNCIA', background_color=(0.5,0.3,0.7,1),
                         background_normal='', color=(1,1,1,1), font_size=sp(14))
        btn_freq.bind(on_release=self.abrir_frequencia)
        btn_row2.add_widget(btn_freq)

        btn_excl = Button(text='🗑 EXCLUIR', background_color=(0.8,0.1,0.1,1),
                         background_normal='', color=(1,1,1,1), font_size=sp(14))
        btn_excl.bind(on_release=self.confirmar_exclusao)
        btn_row2.add_widget(btn_excl)
        container.add_widget(btn_row2)

        # Graduações
        container.add_widget(Widget(size_hint_y=None, height=dp(12)))
        container.add_widget(Label(text='🥋 GRADUAÇÕES', font_size=sp(16), bold=True,
                                   color=(0.827,0.184,0.184,1), size_hint_y=None, height=dp(30)))

        # Form nova graduação
        grad_card = CardWidget()
        grad_card.add_widget(Label(text='Nova Graduação', font_size=sp(14), bold=True,
                                   color=(1,1,1,1), size_hint_y=None, height=dp(24)))

        self._grad_data = TextInput(hint_text='Data (YYYY-MM-DD)', text=date.today().isoformat(),
                                   multiline=False, size_hint_y=None, height=dp(40),
                                   background_color=(0.15,0.15,0.15,1),
                                   foreground_color=(1,1,1,1), font_size=sp(13),
                                   padding=[dp(8), dp(8)])
        grad_card.add_widget(self._grad_data)

        self._grad_faixa = TextInput(hint_text='Faixa', multiline=False,
                                    size_hint_y=None, height=dp(40),
                                    background_color=(0.15,0.15,0.15,1),
                                    foreground_color=(1,1,1,1), font_size=sp(13),
                                    padding=[dp(8), dp(8)])
        grad_card.add_widget(self._grad_faixa)

        self._grad_obs = TextInput(hint_text='Observação', multiline=False,
                                  size_hint_y=None, height=dp(40),
                                  background_color=(0.15,0.15,0.15,1),
                                  foreground_color=(1,1,1,1), font_size=sp(13),
                                  padding=[dp(8), dp(8)])
        grad_card.add_widget(self._grad_obs)

        btn_grad = Button(text='➕ Registrar Graduação', size_hint_y=None, height=dp(40),
                         background_color=(0.827,0.184,0.184,1), background_normal='',
                         color=(1,1,1,1), font_size=sp(13))
        btn_grad.bind(on_release=self.registrar_graduacao)
        grad_card.add_widget(btn_grad)
        grad_card.height = dp(230)
        container.add_widget(grad_card)

        # Lista graduações
        for g in graduacoes:
            gc = CardWidget()
            gc.add_widget(Label(text=f'🥋 {g[3]} — {g[2]}', font_size=sp(13),
                                color=(1,1,1,1), size_hint_y=None, height=dp(22)))
            if g[4]:
                gc.add_widget(Label(text=f'Obs: {g[4]}', font_size=sp(11),
                                    color=(0.6,0.6,0.6,1), size_hint_y=None, height=dp(18)))
            btn_del = Button(text='🗑', size_hint_y=None, height=dp(32), size_hint_x=0.3,
                            background_color=(0.5,0.1,0.1,1), background_normal='',
                            color=(1,1,1,1))
            btn_del.bind(on_release=partial(self.excluir_graduacao, g[0]))
            gc.add_widget(btn_del)
            gc.height = dp(90)
            container.add_widget(gc)

        container.add_widget(Widget(size_hint_y=None, height=dp(30)))

    def _get_val(self, key):
        w = self._inputs.get(key)
        if w is None:
            return ''
        if isinstance(w, Spinner):
            return w.text
        return w.text.strip()

    def salvar(self, *args):
        conn = get_db()
        conn.execute("""
            UPDATE alunos SET nome=?,sexo=?,data_nascimento=?,faixa_atual=?,tipo=?,valor_mensalidade=?,
            dia_vencimento=?,telefone=?,responsavel=?,data_matricula=?,turma=?,horario=?,
            modalidade=?,observacoes=?,ativo=? WHERE id=?
        """, (
            self._get_val('nome'), self._get_val('sexo'), self._get_val('data_nascimento'),
            self._get_val('faixa'), self._get_val('tipo'),
            float(self._get_val('valor') or 0),
            int(self._get_val('dia_vencimento') or 5),
            self._get_val('telefone'), self._get_val('responsavel'),
            self._get_val('data_matricula'), self._get_val('turma'),
            self._get_val('horario'), self._get_val('modalidade'),
            self._get_val('observacoes'),
            1 if self._ativo_check.active else 0,
            self.aluno_id
        ))
        conn.commit()
        conn.close()
        self._show_msg('✅ Aluno atualizado!')

    def abrir_pagamentos(self, *args):
        app = App.get_running_app()
        screen = app.root.ids.sm.get_screen('pagamentos')
        screen.aluno_id = self.aluno_id
        app.go_screen('pagamentos')

    def abrir_frequencia(self, *args):
        conn = get_db()
        a = conn.execute("SELECT nome FROM alunos WHERE id=?", (self.aluno_id,)).fetchone()
        conn.close()
        if a:
            app = App.get_running_app()
            screen = app.root.ids.sm.get_screen('frequencia_aluno')
            screen.aluno_nome = a[0]
            app.go_screen('frequencia_aluno')

    def registrar_graduacao(self, *args):
        faixa = self._grad_faixa.text.strip()
        if not faixa:
            return
        conn = get_db()
        conn.execute(
            "INSERT INTO graduacoes (aluno_id, data_graduacao, faixa, observacao) VALUES (?,?,?,?)",
            (self.aluno_id, self._grad_data.text.strip(), faixa, self._grad_obs.text.strip())
        )
        conn.execute("UPDATE alunos SET faixa_atual=? WHERE id=?", (faixa, self.aluno_id))
        conn.commit()
        conn.close()
        self.build_form()

    def excluir_graduacao(self, grad_id, *args):
        conn = get_db()
        conn.execute("DELETE FROM graduacoes WHERE id=?", (grad_id,))
        conn.commit()
        conn.close()
        self.build_form()

    def confirmar_exclusao(self, *args):
        content = BoxLayout(orientation='vertical', padding=dp(16), spacing=dp(12))
        content.add_widget(Label(text='Tem certeza que deseja\nexcluir este aluno?',
                                color=(1,1,1,1), font_size=sp(14)))
        btn_row = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
        popup = Popup(title='⚠️ Confirmar Exclusão', content=content,
                     size_hint=(0.8, 0.4), background_color=(0.1,0.1,0.1,0.95))

        btn_sim = Button(text='SIM, EXCLUIR', background_color=(0.8,0.1,0.1,1),
                        background_normal='', color=(1,1,1,1))
        btn_sim.bind(on_release=lambda x: self._excluir_aluno(popup))
        btn_nao = Button(text='CANCELAR', background_color=(0.3,0.3,0.3,1),
                        background_normal='', color=(1,1,1,1))
        btn_nao.bind(on_release=popup.dismiss)
        btn_row.add_widget(btn_sim)
        btn_row.add_widget(btn_nao)
        content.add_widget(btn_row)
        popup.open()

    def _excluir_aluno(self, popup):
        conn = get_db()
        c = conn.cursor()
        c.execute("DELETE FROM pagamentos WHERE aluno_id=?", (self.aluno_id,))
        c.execute("DELETE FROM presencas WHERE aluno=(SELECT nome FROM alunos WHERE id=?)",
                 (self.aluno_id,))
        c.execute("DELETE FROM graduacoes WHERE aluno_id=?", (self.aluno_id,))
        c.execute("DELETE FROM alunos WHERE id=?", (self.aluno_id,))
        conn.commit()
        conn.close()
        popup.dismiss()
        App.get_running_app().go_screen('alunos')

    def _show_msg(self, msg):
        popup = Popup(title='', content=Label(text=msg, color=(1,1,1,1)),
                     size_hint=(0.7, 0.25), background_color=(0.1,0.1,0.1,0.95))
        popup.open()


class ReconhecimentoScreen(Screen):
    def on_enter(self):
        self.build_ui()

    def build_ui(self):
        container = self.ids.reconhecimento_content
        container.clear_widgets()

        container.add_widget(Label(text='📸 RECONHECIMENTO FACIAL', font_size=sp(20), bold=True,
                                   color=(0.827,0.184,0.184,1), size_hint_y=None, height=dp(40)))

        card = CardWidget()
        card.add_widget(Label(text='Cadastre alunos com foto para\nreconhecimento por face.',
                             font_size=sp(14), color=(1,1,1,1), size_hint_y=None, height=dp(44),
                             halign='center'))

        btn_cam = Button(text='📷 TIRAR FOTO PARA IDENTIFICAR', size_hint_y=None, height=dp(52),
                        background_color=(0.827,0.184,0.184,1), background_normal='',
                        color=(1,1,1,1), font_size=sp(14), bold=True)
        btn_cam.bind(on_release=self.identificar_camera)
        card.add_widget(btn_cam)

        btn_gal = Button(text='🖼 SELECIONAR FOTO PARA IDENTIFICAR', size_hint_y=None, height=dp(52),
                        background_color=(0.1,0.1,0.1,1), background_normal='',
                        color=(1,1,1,1), font_size=sp(14), bold=True)
        btn_gal.bind(on_release=self.identificar_galeria)
        card.add_widget(btn_gal)
        card.height = dp(200)
        container.add_widget(card)

        # Lista alunos com foto
        conn = get_db()
        alunos_com_foto = conn.execute(
            "SELECT id, nome, foto_path FROM alunos WHERE ativo=1 AND foto_path != '' ORDER BY nome"
        ).fetchall()
        alunos_sem_foto = conn.execute(
            "SELECT id, nome FROM alunos WHERE ativo=1 AND (foto_path IS NULL OR foto_path='') ORDER BY nome"
        ).fetchall()
        conn.close()

        container.add_widget(Label(text=f'✅ {len(alunos_com_foto)} aluno(s) com foto cadastrada',
                                   font_size=sp(13), color=(0.2,0.8,0.2,1),
                                   size_hint_y=None, height=dp(28)))

        if alunos_sem_foto:
            container.add_widget(Label(text=f'⚠️ {len(alunos_sem_foto)} aluno(s) SEM foto:',
                                       font_size=sp(13), color=(1,0.5,0.2,1),
                                       size_hint_y=None, height=dp(28)))
            for a in alunos_sem_foto:
                row = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(8))
                row.add_widget(Label(text=a[1], font_size=sp(13), color=(1,1,1,1),
                                     size_hint_x=0.6, halign='left', text_size=(None, None)))
                btn = Button(text='📷 Add Foto', size_hint_x=0.4, size_hint_y=None, height=dp(36),
                            background_color=(0.827,0.184,0.184,1), background_normal='',
                            color=(1,1,1,1), font_size=sp(12))
                btn.bind(on_release=partial(self.add_foto_aluno, a[0]))
                row.add_widget(btn)
                container.add_widget(row)

        container.add_widget(Widget(size_hint_y=None, height=dp(30)))

    def identificar_camera(self, *args):
        if platform == 'android':
            try:
                from android.permissions import request_permissions, Permission
                request_permissions([Permission.CAMERA])
            except:
                pass
        if HAS_PLYER:
            try:
                filepath = os.path.join(FOTOS_DIR, f"identificar_{datetime.now().strftime('%Y%m%d%H%M%S')}.jpg")
                camera.take_picture(filename=filepath, on_complete=self._processar_identificacao)
            except Exception as e:
                self._show_msg(f"Erro: {e}")
        else:
            self._show_msg("Câmera não disponível")

    def identificar_galeria(self, *args):
        if HAS_PLYER:
            try:
                filechooser.open_file(on_selection=lambda sel: self._processar_identificacao(sel[0] if sel else None),
                                     filters=["*.jpg", "*.jpeg", "*.png"])
            except Exception as e:
                self._show_msg(f"Erro: {e}")
        else:
            self._show_msg("Seletor não disponível")

    def _processar_identificacao(self, filepath):
        if not filepath or not os.path.exists(filepath):
            self._show_msg("Nenhuma foto capturada")
            return
        # Em Android real usaria ML Kit Face Detection + comparação de embeddings
        # Aqui fazemos comparação simples como placeholder
        self._show_msg("📸 Foto capturada!\nUse a versão completa com ML Kit\npara reconhecimento automático.")

    def add_foto_aluno(self, aluno_id, *args):
        if HAS_PLYER:
            try:
                filepath = os.path.join(FOTOS_DIR, f"aluno_{aluno_id}_{datetime.now().strftime('%Y%m%d%H%M%S')}.jpg")
                camera.take_picture(filename=filepath,
                                   on_complete=partial(self._salvar_foto_aluno, aluno_id))
            except:
                try:
                    filechooser.open_file(
                        on_selection=lambda sel: self._salvar_foto_aluno_file(aluno_id, sel),
                        filters=["*.jpg", "*.jpeg", "*.png"])
                except Exception as e:
                    self._show_msg(f"Erro: {e}")
        else:
            self._show_msg("Câmera/galeria não disponível")

    def _salvar_foto_aluno(self, aluno_id, filepath):
        if filepath and os.path.exists(filepath):
            conn = get_db()
            conn.execute("UPDATE alunos SET foto_path=? WHERE id=?", (filepath, aluno_id))
            conn.commit()
            conn.close()
            self.build_ui()

    def _salvar_foto_aluno_file(self, aluno_id, selection):
        if selection:
            src = selection[0]
            ext = os.path.splitext(src)[1]
            dest = os.path.join(FOTOS_DIR, f"aluno_{aluno_id}{ext}")
            shutil.copy2(src, dest)
            conn = get_db()
            conn.execute("UPDATE alunos SET foto_path=? WHERE id=?", (dest, aluno_id))
            conn.commit()
            conn.close()
            self.build_ui()

    def _show_msg(self, msg):
        popup = Popup(title='', content=Label(text=msg, color=(1,1,1,1)),
                     size_hint=(0.8, 0.3), background_color=(0.1,0.1,0.1,0.95))
        popup.open()


class PresencasScreen(Screen):
    _checkboxes = {}

    def on_enter(self):
        horarios = ['Todos'] + listar_horarios()
        self.ids.horario_presenca.values = horarios
        self.ids.data_presenca.text = date.today().isoformat()
        self.carregar()

    def carregar(self, *args):
        container = self.ids.lista_presencas
        container.clear_widgets()
        self._checkboxes = {}

        data_sel = self.ids.data_presenca.text.strip() or date.today().isoformat()
        horario = self.ids.horario_presenca.text

        conn = get_db()
        if horario and horario != 'Todos':
            alunos = conn.execute(
                "SELECT id, nome, turma, horario FROM alunos WHERE ativo=1 AND horario=? ORDER BY nome",
                (horario,)
            ).fetchall()
        else:
            alunos = conn.execute(
                "SELECT id, nome, turma, horario FROM alunos WHERE ativo=1 ORDER BY nome"
            ).fetchall()

        pres = conn.execute("SELECT aluno FROM presencas WHERE data=?", (data_sel,)).fetchall()
        pres_set = set(p[0] for p in pres)
        conn.close()

        eh_hoje = data_sel == date.today().isoformat()
        container.add_widget(Label(
            text=f'{"📅 HOJE" if eh_hoje else "📅 " + data_sel} — {len(alunos)} aluno(s) — {len(pres_set)} presente(s)',
            font_size=sp(13), color=(0.827,0.184,0.184,1), size_hint_y=None, height=dp(28)
        ))

        for a in alunos:
            row = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8), padding=[dp(4), 0])
            with row.canvas.before:
                Color(0.18, 0.18, 0.18, 1)
                row._bg = RoundedRectangle(pos=row.pos, size=row.size, radius=[dp(6)])
            row.bind(pos=lambda w, *a: setattr(w._bg, 'pos', w.pos),
                    size=lambda w, *a: setattr(w._bg, 'size', w.size))

            cb = CheckBox(active=(a[1] in pres_set), size_hint_x=0.12,
                         color=(0.827,0.184,0.184,1))
            self._checkboxes[a[1]] = cb
            row.add_widget(cb)
            row.add_widget(Label(text=a[1], font_size=sp(14), color=(1,1,1,1),
                                 size_hint_x=0.58, halign='left', text_size=(None, None)))
            turma_text = f'{a[2] or ""} {a[3] or ""}'.strip()
            row.add_widget(Label(text=turma_text, font_size=sp(11), color=(0.6,0.6,0.6,1),
                                 size_hint_x=0.3, halign='right', text_size=(None, None)))
            container.add_widget(row)

    def salvar_presencas(self, *args):
        data_sel = self.ids.data_presenca.text.strip() or date.today().isoformat()
        horario = self.ids.horario_presenca.text

        presentes = [nome for nome, cb in self._checkboxes.items() if cb.active]

        conn = get_db()
        c = conn.cursor()
        if horario and horario != 'Todos':
            c.execute(
                "DELETE FROM presencas WHERE data=? AND aluno IN "
                "(SELECT nome FROM alunos WHERE horario=?)",
                (data_sel, horario)
            )
        else:
            c.execute("DELETE FROM presencas WHERE data=?", (data_sel,))

        for nome in presentes:
            c.execute("INSERT INTO presencas (data, aluno) VALUES (?,?)", (data_sel, nome))
        conn.commit()
        conn.close()

        msg = f"✅ {len(presentes)} presença(s) salvas!"
        if horario and horario != 'Todos':
            msg += f"\nHorário: {horario}"
        popup = Popup(title='', content=Label(text=msg, color=(1,1,1,1)),
                     size_hint=(0.7, 0.25), background_color=(0.1,0.1,0.1,0.95))
        popup.open()

    def marcar_todos(self, *args):
        for cb in self._checkboxes.values():
            cb.active = True


class RelatorioFrequenciaScreen(Screen):
    def on_enter(self):
        self.carregar()

    def carregar(self):
        container = self.ids.relatorio_content
        container.clear_widgets()

        conn = get_db()
        ranking = conn.execute(
            "SELECT aluno, COUNT(*) FROM presencas GROUP BY aluno ORDER BY 2 DESC"
        ).fetchall()

        meses = []
        for i in range(5, -1, -1):
            m = datetime.now().month - i
            a = datetime.now().year
            while m < 1: m += 12; a -= 1
            while m > 12: m -= 12; a += 1
            meses.append(f"{a}-{m:02d}")

        freq_mensal = []
        for mes in meses:
            total = conn.execute(
                "SELECT COUNT(DISTINCT aluno) FROM presencas WHERE data LIKE ?",
                (mes + "-%",)
            ).fetchone()[0]
            freq_mensal.append((mes, total))
        conn.close()

        container.add_widget(Label(text='📈 FREQUÊNCIA MENSAL', font_size=sp(18), bold=True,
                                   color=(0.827,0.184,0.184,1), size_hint_y=None, height=dp(36)))

        for mes, total in freq_mensal:
            card = CardWidget()
            card.add_widget(Label(text=f'{mes}: {total} alunos únicos', font_size=sp(14),
                                  color=(1,1,1,1), size_hint_y=None, height=dp(24)))
            card.height = dp(44)
            container.add_widget(card)

        container.add_widget(Widget(size_hint_y=None, height=dp(16)))
        container.add_widget(Label(text='🏆 RANKING DE FREQUÊNCIA', font_size=sp(18), bold=True,
                                   color=(0.827,0.184,0.184,1), size_hint_y=None, height=dp(36)))

        for i, (aluno, count) in enumerate(ranking):
            medalha = ['🥇', '🥈', '🥉'][i] if i < 3 else f'{i+1}.'
            row = BoxLayout(size_hint_y=None, height=dp(36), spacing=dp(8))
            with row.canvas.before:
                Color(0.18, 0.18, 0.18, 1)
                row._bg = RoundedRectangle(pos=row.pos, size=row.size, radius=[dp(6)])
            row.bind(pos=lambda w, *a: setattr(w._bg, 'pos', w.pos),
                    size=lambda w, *a: setattr(w._bg, 'size', w.size))
            row.add_widget(Label(text=f'{medalha} {aluno}', font_size=sp(13),
                                 color=(1,1,1,1), size_hint_x=0.7, halign='left',
                                 text_size=(None, None)))
            row.add_widget(Label(text=f'{count}x', font_size=sp(13), bold=True,
                                 color=(0.827,0.184,0.184,1), size_hint_x=0.3))

            # Tornar clicável para ver frequência do aluno
            btn = Button(text='', background_color=(0,0,0,0), size_hint=(1,1),
                        pos_hint={'x': 0, 'y': 0})
            btn.bind(on_release=partial(self.ver_frequencia, aluno))
            row.add_widget(btn)
            container.add_widget(row)

        container.add_widget(Widget(size_hint_y=None, height=dp(30)))

    def ver_frequencia(self, nome, *args):
        app = App.get_running_app()
        screen = app.root.ids.sm.get_screen('frequencia_aluno')
        screen.aluno_nome = nome
        app.go_screen('frequencia_aluno')


class PagamentosScreen(Screen):
    aluno_id = NumericProperty(0)

    def on_enter(self):
        self.carregar()

    def carregar(self):
        container = self.ids.pagamentos_content
        container.clear_widgets()

        if not self.aluno_id:
            container.add_widget(Label(text='Selecione um aluno primeiro', color=(0.5,0.5,0.5,1),
                                       size_hint_y=None, height=dp(40)))
            return

        conn = get_db()
        aluno = conn.execute("SELECT * FROM alunos WHERE id=?", (self.aluno_id,)).fetchone()
        historico = conn.execute(
            "SELECT id,competencia,valor_pago,data_pagamento,forma_pagamento "
            "FROM pagamentos WHERE aluno_id=? ORDER BY data_pagamento DESC",
            (self.aluno_id,)
        ).fetchall()
        conn.close()

        if not aluno:
            return

        st = status_aluno(self.aluno_id)
        container.add_widget(Label(text=f'💳 {aluno[1]}', font_size=sp(20), bold=True,
                                   color=(0.827,0.184,0.184,1), size_hint_y=None, height=dp(36)))
        container.add_widget(Label(text=f'Status: {st} | Mensalidade: R$ {aluno[6]:.2f}',
                                   font_size=sp(13), color=(1,1,1,1), size_hint_y=None, height=dp(24)))

        # Form novo pagamento
        card = CardWidget()
        card.add_widget(Label(text='➕ NOVO PAGAMENTO', font_size=sp(15), bold=True,
                             color=(0.2,0.8,0.2,1), size_hint_y=None, height=dp(28)))

        hoje = datetime.now()
        self._pag_data = TextInput(text=date.today().isoformat(), hint_text='Data Pagamento',
                                  multiline=False, size_hint_y=None, height=dp(40),
                                  background_color=(0.15,0.15,0.15,1),
                                  foreground_color=(1,1,1,1), font_size=sp(13),
                                  padding=[dp(8), dp(8)])
        card.add_widget(self._pag_data)

        self._pag_comp = TextInput(text=f"{hoje.year}-{hoje.month:02d}",
                                  hint_text='Competência (YYYY-MM)',
                                  multiline=False, size_hint_y=None, height=dp(40),
                                  background_color=(0.15,0.15,0.15,1),
                                  foreground_color=(1,1,1,1), font_size=sp(13),
                                  padding=[dp(8), dp(8)])
        card.add_widget(self._pag_comp)

        self._pag_valor = TextInput(text=str(aluno[6] or 0), hint_text='Valor Pago',
                                   multiline=False, size_hint_y=None, height=dp(40),
                                   background_color=(0.15,0.15,0.15,1),
                                   foreground_color=(1,1,1,1), font_size=sp(13),
                                   input_filter='float',
                                   padding=[dp(8), dp(8)])
        card.add_widget(self._pag_valor)

        self._pag_forma = Spinner(text='Pix', values=['Pix', 'Dinheiro', 'Cartão', 'Transferência'],
                                 size_hint_y=None, height=dp(40), background_color=(0.2,0.2,0.2,1),
                                 color=(1,1,1,1), background_normal='', font_size=sp(13))
        card.add_widget(self._pag_forma)

        self._pag_obs = TextInput(hint_text='Observação (opcional)', multiline=False,
                                 size_hint_y=None, height=dp(40),
                                 background_color=(0.15,0.15,0.15,1),
                                 foreground_color=(1,1,1,1), font_size=sp(13),
                                 padding=[dp(8), dp(8)])
        card.add_widget(self._pag_obs)

        btn_reg = Button(text='💾 REGISTRAR PAGAMENTO', size_hint_y=None, height=dp(44),
                        background_color=(0.2,0.7,0.2,1), background_normal='',
                        color=(1,1,1,1), font_size=sp(14), bold=True)
        btn_reg.bind(on_release=self.registrar_pagamento)
        card.add_widget(btn_reg)
        card.height = dp(340)
        container.add_widget(card)

        # Histórico
        container.add_widget(Label(text='📋 HISTÓRICO', font_size=sp(16), bold=True,
                                   color=(0.827,0.184,0.184,1), size_hint_y=None, height=dp(32)))

        for h in historico:
            hc = CardWidget()
            hc.add_widget(Label(text=f'📅 {h[1]} — R$ {h[2]:.2f}', font_size=sp(14),
                                color=(1,1,1,1), size_hint_y=None, height=dp(22)))
            hc.add_widget(Label(text=f'Pago em: {h[3]} | {h[4] or ""}', font_size=sp(11),
                                color=(0.6,0.6,0.6,1), size_hint_y=None, height=dp(18)))
            btn_row = BoxLayout(size_hint_y=None, height=dp(36), spacing=dp(8))
            btn_edit = Button(text='✏️ Editar', background_color=(0.3,0.5,0.7,1),
                            background_normal='', color=(1,1,1,1), font_size=sp(12))
            btn_edit.bind(on_release=partial(self.editar_pagamento, h[0]))
            btn_del = Button(text='🗑 Excluir', background_color=(0.7,0.1,0.1,1),
                           background_normal='', color=(1,1,1,1), font_size=sp(12))
            btn_del.bind(on_release=partial(self.excluir_pagamento, h[0]))
            btn_row.add_widget(btn_edit)
            btn_row.add_widget(btn_del)
            hc.add_widget(btn_row)
            hc.height = dp(95)
            container.add_widget(hc)

        container.add_widget(Widget(size_hint_y=None, height=dp(30)))

    def registrar_pagamento(self, *args):
        conn = get_db()
        conn.execute(
            "INSERT INTO pagamentos (aluno_id,data_pagamento,competencia,valor_pago,"
            "forma_pagamento,observacao) VALUES (?,?,?,?,?,?)",
            (self.aluno_id, self._pag_data.text.strip(), self._pag_comp.text.strip(),
             float(self._pag_valor.text or 0), self._pag_forma.text,
             self._pag_obs.text.strip())
        )
        conn.commit()
        conn.close()
        self.carregar()

    def editar_pagamento(self, pag_id, *args):
        conn = get_db()
        p = conn.execute("SELECT * FROM pagamentos WHERE id=?", (pag_id,)).fetchone()
        conn.close()
        if not p:
            return

        content = BoxLayout(orientation='vertical', padding=dp(12), spacing=dp(8))

        data_inp = TextInput(text=p[2] or '', hint_text='Data', multiline=False,
                            size_hint_y=None, height=dp(40),
                            background_color=(0.15,0.15,0.15,1), foreground_color=(1,1,1,1),
                            font_size=sp(13), padding=[dp(8), dp(8)])
        comp_inp = TextInput(text=p[3] or '', hint_text='Competência', multiline=False,
                            size_hint_y=None, height=dp(40),
                            background_color=(0.15,0.15,0.15,1), foreground_color=(1,1,1,1),
                            font_size=sp(13), padding=[dp(8), dp(8)])
        valor_inp = TextInput(text=str(p[4] or 0), hint_text='Valor', multiline=False,
                             size_hint_y=None, height=dp(40), input_filter='float',
                             background_color=(0.15,0.15,0.15,1), foreground_color=(1,1,1,1),
                             font_size=sp(13), padding=[dp(8), dp(8)])
        forma_inp = Spinner(text=p[5] or 'Pix', values=['Pix', 'Dinheiro', 'Cartão', 'Transferência'],
                           size_hint_y=None, height=dp(40), background_color=(0.2,0.2,0.2,1),
                           color=(1,1,1,1), background_normal='', font_size=sp(13))
        obs_inp = TextInput(text=p[6] or '', hint_text='Observação', multiline=False,
                           size_hint_y=None, height=dp(40),
                           background_color=(0.15,0.15,0.15,1), foreground_color=(1,1,1,1),
                           font_size=sp(13), padding=[dp(8), dp(8)])

        content.add_widget(Label(text='Data Pagamento:', color=(0.7,0.7,0.7,1),
                                 size_hint_y=None, height=dp(20), font_size=sp(12)))
        content.add_widget(data_inp)
        content.add_widget(Label(text='Competência:', color=(0.7,0.7,0.7,1),
                                 size_hint_y=None, height=dp(20), font_size=sp(12)))
        content.add_widget(comp_inp)
        content.add_widget(Label(text='Valor:', color=(0.7,0.7,0.7,1),
                                 size_hint_y=None, height=dp(20), font_size=sp(12)))
        content.add_widget(valor_inp)
        content.add_widget(Label(text='Forma:', color=(0.7,0.7,0.7,1),
                                 size_hint_y=None, height=dp(20), font_size=sp(12)))
        content.add_widget(forma_inp)
        content.add_widget(Label(text='Observação:', color=(0.7,0.7,0.7,1),
                                 size_hint_y=None, height=dp(20), font_size=sp(12)))
        content.add_widget(obs_inp)

        popup = Popup(title='✏️ Editar Pagamento', content=content,
                     size_hint=(0.9, 0.85), background_color=(0.1,0.1,0.1,0.98))

        btn_row = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
        btn_save = Button(text='💾 SALVAR', background_color=(0.2,0.7,0.2,1),
                         background_normal='', color=(1,1,1,1), font_size=sp(14))

        def do_save(*a):
            conn2 = get_db()
            conn2.execute(
                "UPDATE pagamentos SET data_pagamento=?,competencia=?,valor_pago=?,"
                "forma_pagamento=?,observacao=? WHERE id=?",
                (data_inp.text, comp_inp.text, float(valor_inp.text or 0),
                 forma_inp.text, obs_inp.text, pag_id)
            )
            conn2.commit()
            conn2.close()
            popup.dismiss()
            self.carregar()

        btn_save.bind(on_release=do_save)
        btn_cancel = Button(text='CANCELAR', background_color=(0.3,0.3,0.3,1),
                           background_normal='', color=(1,1,1,1), font_size=sp(14))
        btn_cancel.bind(on_release=popup.dismiss)
        btn_row.add_widget(btn_save)
        btn_row.add_widget(btn_cancel)
        content.add_widget(btn_row)
        popup.open()

    def excluir_pagamento(self, pag_id, *args):
        conn = get_db()
        conn.execute("DELETE FROM pagamentos WHERE id=?", (pag_id,))
        conn.commit()
        conn.close()
        self.carregar()


class InadimplentesScreen(Screen):
    def on_enter(self):
        horarios = ['Todos'] + listar_horarios()
        self.ids.horario_inad.values = horarios
        self.carregar()

    def carregar(self, *args):
        container = self.ids.lista_inadimplentes
        container.clear_widgets()

        horario = self.ids.horario_inad.text

        conn = get_db()
        if horario and horario != 'Todos':
            alunos = conn.execute(
                "SELECT id,nome,valor_mensalidade,tipo,telefone,turma,horario FROM alunos "
                "WHERE ativo=1 AND horario=? ORDER BY nome", (horario,)
            ).fetchall()
        else:
            alunos = conn.execute(
                "SELECT id,nome,valor_mensalidade,tipo,telefone,turma,horario FROM alunos "
                "WHERE ativo=1 ORDER BY nome"
            ).fetchall()
        conn.close()

        lista = []
        for a in alunos:
            s = status_aluno(a[0])
            if "Atrasado" in s or "Sem pagamento" in s:
                meses = calcular_meses_atraso(a[0])
                lista.append((a[0], a[1], a[2], s, a[4], a[5], meses, a[6]))

        container.add_widget(Label(
            text=f'🔴 {len(lista)} inadimplente(s)',
            font_size=sp(14), bold=True, color=(1,0.3,0.3,1),
            size_hint_y=None, height=dp(28)
        ))

        for item in lista:
            card = CardWidget()
            card.add_widget(Label(text=f'{item[1]}', font_size=sp(15), bold=True,
                                  color=(1,1,1,1), size_hint_y=None, height=dp(22),
                                  halign='left', text_size=(None, None)))
            card.add_widget(Label(text=f'{item[3]} | {item[6]} mês(es) atraso',
                                  font_size=sp(12), color=(1,0.5,0.5,1),
                                  size_hint_y=None, height=dp(18),
                                  halign='left', text_size=(None, None)))
            info = f'R$ {item[2]:.2f} | {item[5] or ""} | {item[7] or ""}'
            card.add_widget(Label(text=info, font_size=sp(11), color=(0.6,0.6,0.6,1),
                                  size_hint_y=None, height=dp(18),
                                  halign='left', text_size=(None, None)))
            if item[4]:
                card.add_widget(Label(text=f'📱 {item[4]}', font_size=sp(11),
                                      color=(0.5,0.7,1,1), size_hint_y=None, height=dp(18),
                                      halign='left', text_size=(None, None)))

            btn_pag = Button(text='💳 Pagamentos', size_hint_y=None, height=dp(36),
                            background_color=(0.827,0.184,0.184,1), background_normal='',
                            color=(1,1,1,1), font_size=sp(12))
            btn_pag.bind(on_release=partial(self.abrir_pagamento, item[0]))
            card.add_widget(btn_pag)
            card.height = dp(140) if item[4] else dp(120)
            container.add_widget(card)

        container.add_widget(Widget(size_hint_y=None, height=dp(30)))

    def abrir_pagamento(self, aid, *args):
        app = App.get_running_app()
        screen = app.root.ids.sm.get_screen('pagamentos')
        screen.aluno_id = aid
        app.go_screen('pagamentos')


class HistoricoFinanceiroScreen(Screen):
    def on_enter(self):
        self.carregar()

    def carregar(self):
        container = self.ids.historico_content
        container.clear_widgets()

        conn = get_db()
        c = conn.cursor()
        rm = c.execute(
            "SELECT competencia,COALESCE(SUM(valor_pago),0) FROM pagamentos "
            "GROUP BY competencia ORDER BY competencia DESC LIMIT 12"
        ).fetchall()

        ta = c.execute(
            "SELECT a.id,a.nome,COALESCE(SUM(p.valor_pago),0) FROM alunos a "
            "LEFT JOIN pagamentos p ON a.id=p.aluno_id WHERE a.ativo=1 "
            "GROUP BY a.id ORDER BY 3 DESC"
        ).fetchall()
        conn.close()

        container.add_widget(Label(text='💰 RECEITA MENSAL', font_size=sp(18), bold=True,
                                   color=(0.827,0.184,0.184,1), size_hint_y=None, height=dp(36)))

        total_geral = 0
        for comp, valor in rm:
            total_geral += valor
            card = CardWidget()
            card.add_widget(Label(text=f'{comp}', font_size=sp(14), bold=True,
                                  color=(1,1,1,1), size_hint_y=None, height=dp(22)))
            card.add_widget(Label(text=f'R$ {valor:.2f}', font_size=sp(16), bold=True,
                                  color=(0.2,0.8,0.2,1), size_hint_y=None, height=dp(24)))
            card.height = dp(60)
            container.add_widget(card)

        container.add_widget(Label(text=f'Total últimos 12 meses: R$ {total_geral:.2f}',
                                   font_size=sp(14), bold=True, color=(1,0.8,0.2,1),
                                   size_hint_y=None, height=dp(30)))

        container.add_widget(Widget(size_hint_y=None, height=dp(16)))
        container.add_widget(Label(text='👤 TOTAL POR ALUNO', font_size=sp(18), bold=True,
                                   color=(0.827,0.184,0.184,1), size_hint_y=None, height=dp(36)))

        for a in ta:
            row = BoxLayout(size_hint_y=None, height=dp(36), spacing=dp(8), padding=[dp(8), 0])
            with row.canvas.before:
                Color(0.18, 0.18, 0.18, 1)
                row._bg = RoundedRectangle(pos=row.pos, size=row.size, radius=[dp(6)])
            row.bind(pos=lambda w, *a: setattr(w._bg, 'pos', w.pos),
                    size=lambda w, *a: setattr(w._bg, 'size', w.size))
            row.add_widget(Label(text=a[1], font_size=sp(13), color=(1,1,1,1),
                                 size_hint_x=0.6, halign='left', text_size=(None, None)))
            row.add_widget(Label(text=f'R$ {a[2]:.2f}', font_size=sp(13), bold=True,
                                 color=(0.2,0.8,0.2,1), size_hint_x=0.4,
                                 halign='right', text_size=(None, None)))
            container.add_widget(row)

        container.add_widget(Widget(size_hint_y=None, height=dp(30)))


class FrequenciaAlunoScreen(Screen):
    aluno_nome = StringProperty('')

    def on_enter(self):
        self.carregar()

    def carregar(self):
        container = self.ids.freq_content
        container.clear_widgets()

        if not self.aluno_nome:
            return

        conn = get_db()
        presencas = conn.execute(
            "SELECT data FROM presencas WHERE aluno=? ORDER BY data DESC",
            (self.aluno_nome,)
        ).fetchall()
        conn.close()

        container.add_widget(Label(text=f'📅 {self.aluno_nome}', font_size=sp(20), bold=True,
                                   color=(0.827,0.184,0.184,1), size_hint_y=None, height=dp(36)))
        container.add_widget(Label(text=f'Total: {len(presencas)} presença(s)', font_size=sp(14),
                                   color=(1,1,1,1), size_hint_y=None, height=dp(24)))

        # Botão excluir todas
        if presencas:
            btn_del = Button(text='🗑 Excluir Todas as Presenças', size_hint_y=None, height=dp(40),
                            background_color=(0.7,0.1,0.1,1), background_normal='',
                            color=(1,1,1,1), font_size=sp(13))
            btn_del.bind(on_release=self.excluir_todas)
            container.add_widget(btn_del)

        for p in presencas:
            row = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(8), padding=[dp(8), 0])
            with row.canvas.before:
                Color(0.18, 0.18, 0.18, 1)
                row._bg = RoundedRectangle(pos=row.pos, size=row.size, radius=[dp(6)])
            row.bind(pos=lambda w, *a: setattr(w._bg, 'pos', w.pos),
                    size=lambda w, *a: setattr(w._bg, 'size', w.size))

            row.add_widget(Label(text=f'📅 {p[0]}', font_size=sp(14), color=(1,1,1,1),
                                 size_hint_x=0.7, halign='left', text_size=(None, None)))
            btn = Button(text='✖', size_hint_x=0.3, background_color=(0.5,0.1,0.1,1),
                        background_normal='', color=(1,1,1,1), font_size=sp(14))
            btn.bind(on_release=partial(self.excluir_presenca, p[0]))
            row.add_widget(btn)
            container.add_widget(row)

        container.add_widget(Widget(size_hint_y=None, height=dp(30)))

    def excluir_presenca(self, data_p, *args):
        conn = get_db()
        conn.execute("DELETE FROM presencas WHERE data=? AND aluno=?",
                    (data_p, self.aluno_nome))
        conn.commit()
        conn.close()
        self.carregar()

    def excluir_todas(self, *args):
        content = BoxLayout(orientation='vertical', padding=dp(16), spacing=dp(12))
        content.add_widget(Label(text=f'Excluir TODAS as presenças\nde {self.aluno_nome}?',
                                color=(1,1,1,1), font_size=sp(14)))
        popup = Popup(title='⚠️ Confirmar', content=content,
                     size_hint=(0.8, 0.35), background_color=(0.1,0.1,0.1,0.95))

        btn_row = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
        btn_sim = Button(text='SIM', background_color=(0.8,0.1,0.1,1),
                        background_normal='', color=(1,1,1,1))
        btn_sim.bind(on_release=lambda x: self._do_excluir_todas(popup))
        btn_nao = Button(text='NÃO', background_color=(0.3,0.3,0.3,1),
                        background_normal='', color=(1,1,1,1))
        btn_nao.bind(on_release=popup.dismiss)
        btn_row.add_widget(btn_sim)
        btn_row.add_widget(btn_nao)
        content.add_widget(btn_row)
        popup.open()

    def _do_excluir_todas(self, popup):
        conn = get_db()
        conn.execute("DELETE FROM presencas WHERE aluno=?", (self.aluno_nome,))
        conn.commit()
        conn.close()
        popup.dismiss()
        self.carregar()


class ConfiguracoesScreen(Screen):
    def on_enter(self):
        self.build_ui()

    def build_ui(self):
        container = self.ids.config_content
        container.clear_widgets()

        container.add_widget(Label(text='⚙️ CONFIGURAÇÕES', font_size=sp(20), bold=True,
                                   color=(0.827,0.184,0.184,1), size_hint_y=None, height=dp(40)))

        # Info
        card = CardWidget()
        card.add_widget(Label(text='☢ Escola Nuklear v1.0', font_size=sp(16),
                             color=(1,1,1,1), size_hint_y=None, height=dp(24)))
        card.add_widget(Label(text='Gestão completa de academia/escola', font_size=sp(12),
                             color=(0.6,0.6,0.6,1), size_hint_y=None, height=dp(20)))
        card.add_widget(Label(text=f'Banco: {DB_PATH}', font_size=sp(10),
                             color=(0.5,0.5,0.5,1), size_hint_y=None, height=dp(18)))
        card.add_widget(Label(text=f'Fotos: {FOTOS_DIR}', font_size=sp(10),
                             color=(0.5,0.5,0.5,1), size_hint_y=None, height=dp(18)))
        card.height = dp(110)
        container.add_widget(card)

        # Stats
        conn = get_db()
        total = conn.execute("SELECT COUNT(*) FROM alunos").fetchone()[0]
        ativos = conn.execute("SELECT COUNT(*) FROM alunos WHERE ativo=1").fetchone()[0]
        pagamentos = conn.execute("SELECT COUNT(*) FROM pagamentos").fetchone()[0]
        presencas = conn.execute("SELECT COUNT(*) FROM presencas").fetchone()[0]
        conn.close()

        card2 = CardWidget()
        card2.add_widget(Label(text='📊 ESTATÍSTICAS DO BANCO', font_size=sp(15), bold=True,
                              color=(0.827,0.184,0.184,1), size_hint_y=None, height=dp(28)))
        stats = [
            f'Total alunos: {total} ({ativos} ativos)',
            f'Pagamentos registrados: {pagamentos}',
            f'Presenças registradas: {presencas}',
        ]
        for s in stats:
            card2.add_widget(Label(text=s, font_size=sp(13), color=(1,1,1,1),
                                   size_hint_y=None, height=dp(22), halign='left',
                                   text_size=(None, None)))
        card2.height = dp(120)
        container.add_widget(card2)

        # Backup
        btn_backup = Button(text='💾 EXPORTAR BACKUP (JSON)', size_hint_y=None, height=dp(48),
                           background_color=(0.2,0.5,0.8,1), background_normal='',
                           color=(1,1,1,1), font_size=sp(14), bold=True)
        btn_backup.bind(on_release=self.exportar_backup)
        container.add_widget(btn_backup)

        btn_import = Button(text='📥 IMPORTAR BACKUP (JSON)', size_hint_y=None, height=dp(48),
                           background_color=(0.5,0.3,0.7,1), background_normal='',
                           color=(1,1,1,1), font_size=sp(14), bold=True)
        btn_import.bind(on_release=self.importar_backup)
        container.add_widget(btn_import)

        container.add_widget(Widget(size_hint_y=None, height=dp(30)))

    def exportar_backup(self, *args):
        try:
            conn = get_db()
            data = {
                'alunos': [],
                'pagamentos': [],
                'graduacoes': [],
                'presencas': [],
                'export_date': datetime.now().isoformat()
            }
            for table in ['alunos', 'pagamentos', 'graduacoes', 'presencas']:
                rows = conn.execute(f"SELECT * FROM {table}").fetchall()
                cols = [desc[0] for desc in conn.execute(f"SELECT * FROM {table} LIMIT 1").description] if rows else []
                for r in rows:
                    data[table].append(dict(zip(cols, r)))
            conn.close()

            backup_path = os.path.join(APP_DIR, f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
            with open(backup_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)

            self._show_msg(f'✅ Backup exportado!\n{backup_path}')
        except Exception as e:
            self._show_msg(f'❌ Erro: {e}')

    def importar_backup(self, *args):
        if HAS_PLYER:
            try:
                filechooser.open_file(on_selection=self._do_import,
                                     filters=["*.json"])
            except Exception as e:
                self._show_msg(f"Erro: {e}")
        else:
            self._show_msg("Seletor não disponível")

    def _do_import(self, selection):
        if not selection:
            return
        try:
            with open(selection[0], 'r', encoding='utf-8') as f:
                data = json.load(f)
            conn = get_db()
            c = conn.cursor()
            if 'alunos' in data:
                for a in data['alunos']:
                    cols = ', '.join(a.keys())
                    placeholders = ', '.join(['?'] * len(a))
                    c.execute(f"INSERT OR REPLACE INTO alunos ({cols}) VALUES ({placeholders})",
                             list(a.values()))
            if 'pagamentos' in data:
                for p in data['pagamentos']:
                    cols = ', '.join(p.keys())
                    placeholders = ', '.join(['?'] * len(p))
                    c.execute(f"INSERT OR REPLACE INTO pagamentos ({cols}) VALUES ({placeholders})",
                             list(p.values()))
            if 'graduacoes' in data:
                for g in data['graduacoes']:
                    cols = ', '.join(g.keys())
                    placeholders = ', '.join(['?'] * len(g))
                    c.execute(f"INSERT OR REPLACE INTO graduacoes ({cols}) VALUES ({placeholders})",
                             list(g.values()))
            if 'presencas' in data:
                for p in data['presencas']:
                    cols = ', '.join(p.keys())
                    placeholders = ', '.join(['?'] * len(p))
                    c.execute(f"INSERT OR REPLACE INTO presencas ({cols}) VALUES ({placeholders})",
                             list(p.values()))
            conn.commit()
            conn.close()
            self._show_msg('✅ Backup importado com sucesso!')
            self.build_ui()
        except Exception as e:
            self._show_msg(f'❌ Erro: {e}')

    def _show_msg(self, msg):
        popup = Popup(title='', content=Label(text=msg, color=(1,1,1,1)),
                     size_hint=(0.8, 0.3), background_color=(0.1,0.1,0.1,0.95))
        popup.open()


# ─── Root Widget ──────────────────────────────────────────────────────
class RootWidget(BoxLayout):
    pass


# ─── App ──────────────────────────────────────────────────────────────
class EscolaNuklearApp(App):
    _menu_popup = None

    def build(self):
        self.title = 'Escola Nuklear'
        init_db()
        Builder.load_string(KV)
        Window.clearcolor = (0.1, 0.1, 0.1, 1)
        return RootWidget()

    def on_start(self):
        self.go_screen('dashboard')

    def go_screen(self, name, direction='left'):
        sm = self.root.ids.sm
        sm.transition = SlideTransition(direction=direction)
        sm.current = name

    def toggle_menu(self):
        if self._menu_popup:
            self.close_menu()
        else:
            self.open_menu()

    def open_menu(self):
        self._menu_popup = Popup(
            title='', separator_height=0,
            size_hint=(0.75, 1), pos_hint={'x': 0},
            background_color=(0, 0, 0, 0), background='',
            auto_dismiss=True
        )

        main_box = BoxLayout(orientation='vertical', padding=0, spacing=0)
        with main_box.canvas.before:
            Color(0.1, 0.1, 0.1, 1)
            main_box._bg = Rectangle(pos=main_box.pos, size=main_box.size)
        main_box.bind(
            pos=lambda w, *a: setattr(w._bg, 'pos', w.pos),
            size=lambda w, *a: setattr(w._bg, 'size', w.size)
        )

        # Header
        header = BoxLayout(size_hint_y=None, height=dp(80), padding=dp(16))
        with header.canvas.before:
            Color(0.827, 0.184, 0.184, 1)
            header._bg = Rectangle(pos=header.pos, size=header.size)
        header.bind(
            pos=lambda w, *a: setattr(w._bg, 'pos', w.pos),
            size=lambda w, *a: setattr(w._bg, 'size', w.size)
        )
        header.add_widget(Label(text='☢ ESCOLA\nNUKLEAR', font_size=sp(20), bold=True,
                                color=(1,1,1,1), halign='left', text_size=(None, None)))
        main_box.add_widget(header)

        # Menu items
        scroll = ScrollView()
        menu_list = BoxLayout(orientation='vertical', size_hint_y=None, spacing=dp(1))
        menu_list.bind(minimum_height=menu_list.setter('height'))

        items = [
            ('📊  Dashboard', 'dashboard'),
            ('👥  Alunos', 'alunos'),
            ('➕  Cadastrar Aluno', 'cadastrar_aluno'),
            ('📸  Reconhecimento Facial', 'reconhecimento'),
            ('✅  Presenças', 'presencas'),
            ('📈  Relatório Frequência', 'relatorio_frequencia'),
            ('🔴  Inadimplentes', 'inadimplentes'),
            ('💰  Histórico Financeiro', 'historico_financeiro'),
            ('⚙️  Configurações', 'configuracoes'),
        ]

        for text, screen in items:
            btn = Button(text=text, size_hint_y=None, height=dp(50),
                        font_size=sp(15), background_color=(0.12,0.12,0.12,1),
                        background_normal='', color=(1,1,1,1),
                        halign='left', padding=[dp(16), 0])
            btn.text_size = (None, None)
            btn.bind(on_release=partial(self._menu_go, screen))
            menu_list.add_widget(btn)

        scroll.add_widget(menu_list)
        main_box.add_widget(scroll)

        # Footer
        main_box.add_widget(Label(text='v1.0 — Escola Nuklear', font_size=sp(11),
                                  color=(0.5,0.5,0.5,1), size_hint_y=None, height=dp(30)))

        self._menu_popup.content = main_box
        self._menu_popup.open()

    def _menu_go(self, screen, *args):
        self.close_menu()
        self.go_screen(screen)

    def close_menu(self):
        if self._menu_popup:
            self._menu_popup.dismiss()
            self._menu_popup = None


# ─── Widget import needed ────────────────────────────────────────────
from kivy.uix.widget import Widget

if __name__ == '__main__':
    EscolaNuklearApp().run()
