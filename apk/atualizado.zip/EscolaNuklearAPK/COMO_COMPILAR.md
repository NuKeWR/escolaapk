# ☢ COMO COMPILAR O APK — Passo a Passo (Windows Puro)

## ⚠️ O Buildozer NÃO funciona no Windows!

Ele é exclusivo Linux. No PowerShell vai dar erro sempre.

---

## ✅ SOLUÇÃO: Compilar no Google Colab (Grátis)

### Passo 1 — Abra o Google Colab
👉 **https://colab.research.google.com**  
Crie um **novo notebook**.

---

### Passo 2 — Copie CADA célula abaixo e execute uma por vez:

---

#### CÉLULA 1 — Instalar tudo (~3 min)
```python
# Instalar dependências do sistema
!sudo apt-get update -qq
!sudo apt-get install -y -qq \
    git zip unzip openjdk-17-jdk python3-pip \
    autoconf libtool pkg-config \
    zlib1g-dev libncurses5-dev libncursesw5-dev \
    libtinfo5 cmake libffi-dev libssl-dev \
    build-essential ccache

# Instalar buildozer e cython com versões compatíveis
!pip install --upgrade buildozer Cython==0.29.33

print('\n✅ Tudo instalado!')
```

---

#### CÉLULA 2 — Criar pasta do projeto
```python
import os
os.makedirs('/content/EscolaNuklear', exist_ok=True)
os.chdir('/content/EscolaNuklear')
print(f'📁 Pasta: {os.getcwd()}')
```

---

#### CÉLULA 3 — Upload do main.py
```python
from google.colab import files
print('📤 Selecione o arquivo main.py:')
uploaded = files.upload()
print('✅ Upload OK!')
```
> Vai aparecer um botão. Selecione o `main.py` da pasta `EscolaNuklearAPK`.

---

#### CÉLULA 4 — Criar o buildozer.spec
```python
spec_content = """[app]
title = Escola Nuklear
package.name = escolanuklear
package.domain = com.nuklear
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,json
version = 1.0.0
requirements = python3,kivy,pillow,plyer
orientation = portrait
fullscreen = 0
android.permissions = INTERNET,CAMERA,WRITE_EXTERNAL_STORAGE,READ_EXTERNAL_STORAGE
android.api = 33
android.minapi = 21
android.ndk_api = 21
android.accept_sdk_license = True
android.archs = arm64-v8a
android.allow_backup = True
android.apptheme = @android:style/Theme.NoTitleBar
p4a.bootstrap = sdl2
p4a.branch = develop

[buildozer]
log_level = 2
warn_on_root = 0
"""

with open('buildozer.spec', 'w') as f:
    f.write(spec_content)
print('✅ buildozer.spec criado!')
```

---

#### CÉLULA 5 — COMPILAR O APK (~15-25 min)
```python
!buildozer -v android debug 2>&1 | tee build_log.txt | tail -100
```
> ☕ Demora bastante na primeira vez. Não feche a aba!
> 
> **Se der erro**, rode esta célula para ver o log completo:
> ```python
> !grep -i "error" build_log.txt | tail -30
> ```

---

#### CÉLULA 6 — Baixar o APK
```python
import glob
from google.colab import files

apks = glob.glob('bin/*.apk')
if apks:
    print(f'✅ APK pronto: {apks[0]}')
    files.download(apks[0])
else:
    print('❌ APK não encontrado.')
    print('Verifique erros com: !grep -i "error" build_log.txt | tail -30')
```

---

### Passo 3 — Instalar no celular

1. Transfira o `.apk` para o celular (USB, Google Drive, WhatsApp...)
2. Toque no arquivo e instale
3. Se pedir, ative "Fontes desconhecidas" nas configurações
4. Pronto! ☢

---

## 🔧 O que mudou em relação à primeira versão (correções):

| Problema | Correção aplicada |
|---|---|
| `requirements` incompatíveis | Removido `pyjnius` e `android` (já vêm implícitos) |
| `kivy==2.3.0` pode não compilar | Usando `kivy` sem versão fixa (pega a última compatível) |
| p4a branch `master` com bugs | Trocado para `p4a.branch = develop` |
| Cython desatualizado | Fixado em `Cython==0.29.33` |
| Falta de dependências no Colab | Lista completa de apt-get |

---

## ❓ Se ainda der erro

Cole aqui a saída de:
```python
!grep -i "error\|fatal\|failed" build_log.txt | grep -v "ENVIRONMENT" | tail -20
```

Os erros reais ficam **acima** daquela mensagem genérica do buildozer. 
A parte que começa com `ENVIRONMENT:` e lista variáveis não é o erro real — é só contexto.

---

## 🔄 Alternativa: GitHub Actions (automático)

Se o Colab não funcionar, crie um repositório no GitHub com os arquivos 
e use GitHub Actions. Veja o arquivo `.github/workflows/build.yml` incluído.

**Qualquer dúvida, me pergunte!** ☢
