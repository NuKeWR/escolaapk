# ☢ Escola Nuklear — APK Android

Réplica completa do sistema **CT João Filho IA v3.2** para dispositivos Android.

> **Cores:** Vermelho (#D32F2F) e Preto (#1A1A1A)

---

## 📱 Funcionalidades

### Dashboard
- Total de alunos (geral, Kids, Adultos)
- Presentes hoje
- Contagem de inadimplentes
- Financeiro do mês (receita prevista, recebido, em aberto, taxa adimplência)
- Status dos alunos (em dia, atrasados, bolsistas, isentos)
- Alunos por horário
- Aniversariantes do mês

### 👥 Gestão de Alunos
- **Cadastrar** aluno com todos os campos:
  - Nome, sexo, data nascimento, faixa, tipo (Aluno/Bolsista/Professor)
  - Valor mensalidade, dia vencimento, telefone, responsável
  - Turma (Kids/Adulto), horário, modalidade, observações
- **Foto via câmera** ou **galeria** do celular
- **Editar** todos os dados
- **Inativar / Reativar** alunos
- **Excluir** aluno (com cascata em pagamentos, presenças e graduações)
- Filtro por: **horário**, **ativos/inativos/todos**
- Busca por nome

### 📸 Reconhecimento Facial
- Cadastro de foto do aluno (câmera ou galeria)
- Identificação por foto capturada
- Lista de alunos com/sem foto cadastrada
- Botão para adicionar foto a alunos sem cadastro facial

### ✅ Presenças
- Marcar presença por data (padrão = hoje)
- **Filtro por horário** (resolve Kids em horário Adulto)
- Checkbox por aluno
- Botão "Marcar Todos"
- Salvar presenças (recria apenas do horário selecionado)

### 📈 Relatório de Frequência
- Frequência mensal (últimos 6 meses)
- **Ranking** de frequência com medalhas 🥇🥈🥉
- Clique no aluno para ver detalhes

### 📅 Frequência do Aluno
- Lista completa de presenças
- Excluir presença individual
- Excluir todas as presenças

### 💳 Pagamentos
- Registrar pagamento (data, competência, valor, forma, observação)
- Formas: Pix, Dinheiro, Cartão, Transferência
- Editar pagamento existente
- Excluir pagamento
- Histórico completo por aluno

### 🔴 Inadimplentes
- Lista filtrada por horário
- Mostra meses de atraso
- Status financeiro
- Telefone para contato
- Acesso direto aos pagamentos

### 💰 Histórico Financeiro
- Receita mensal (últimos 12 meses)
- Total geral
- Total acumulado por aluno

### 🥋 Graduações
- Registrar nova graduação (data, faixa, observação)
- Atualiza automaticamente a faixa atual do aluno
- Histórico de graduações
- Excluir graduação

### ⚙️ Configurações
- Estatísticas do banco de dados
- **Exportar backup** (JSON completo)
- **Importar backup** (JSON)

---

## 🔧 Como Compilar o APK

### Pré-requisitos (Ubuntu/Debian/WSL2)

```bash
sudo apt update
sudo apt install -y python3-pip build-essential git python3-dev \
    ffmpeg libsdl2-dev libsdl2-image-dev libsdl2-mixer-dev \
    libsdl2-ttf-dev libportmidi-dev libswscale-dev libavformat-dev \
    libavcodec-dev zlib1g-dev libgstreamer1.0-dev \
    gstreamer1.0-plugins-base gstreamer1.0-plugins-good \
    openjdk-17-jdk autoconf libtool pkg-config \
    libncurses5-dev libncursesw5-dev cmake unzip zip

pip install buildozer cython kivy
```

### Build

```bash
cd EscolaNuklearAPK
chmod +x build.sh
./build.sh
```

Ou manualmente:
```bash
buildozer -v android debug
```

O APK será gerado em `bin/escolanuklear-1.0.0-arm64-v8a_armeabi-v7a-debug.apk`

### Instalar no celular

```bash
adb install -r bin/*.apk
```

Ou copie o APK para o celular e instale manualmente.

---

## 🗃 Estrutura do Projeto

```
EscolaNuklearAPK/
├── main.py              # Código principal (2400+ linhas)
├── buildozer.spec       # Configuração do build Android
├── build.sh             # Script de compilação
└── README.md            # Este arquivo
```

### Banco de Dados (SQLite)
- `alunos` — Cadastro completo com 17 campos
- `pagamentos` — Histórico financeiro
- `graduacoes` — Progressão de faixas
- `presencas` — Registro de frequência

---

## 📋 Mapeamento Original → Android

| Função Original (Web Flask) | Equivalente Android |
|---|---|
| `app.py` → Flask routes | `main.py` → Kivy Screens |
| `templates/*.html` | KV Language inline |
| `frequencia.db` (SQLite) | `escola_nuklear.db` (SQLite) |
| `status_financeiro.py` | Função `status_aluno()` integrada |
| `cadastros.json` | Banco SQLite (tabela alunos) |
| InsightFace embeddings | Foto via câmera/galeria + ML Kit (extensível) |
| Flask web interface | Kivy mobile UI nativa |
| Filtro por horário | Spinner com filtro por horário |
| Bot Telegram | — (pode ser adicionado) |

---

## 🎨 Design

- **Tema:** Dark mode com vermelho (#D32F2F) e preto (#1A1A1A)
- **Cards:** Fundo #2E2E2E com cantos arredondados
- **Menu lateral:** Drawer com navegação completa
- **Fontes:** Sistema nativo Android
- **Ícones:** Emojis nativos (sem dependências externas)

---

## 📝 Observações

1. **Reconhecimento Facial:** O sistema original usa InsightFace (incompatível com Android). A versão mobile cadastra fotos e está preparada para integração com ML Kit Face Detection do Google (TFLite). Para ativar reconhecimento automático, integre o `com.google.mlkit:face-detection`.

2. **Dados:** Cada celular tem seu próprio banco local. Use Exportar/Importar backup para sincronizar entre dispositivos.

3. **Permissões:** O app solicita câmera e armazenamento no primeiro uso.

---

**v1.0 — Escola Nuklear** ☢
