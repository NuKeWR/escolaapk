[app]

# (str) Title of your application
title = Escola Nuklear

# (str) Package name
package.name = escolanuklear

# (str) Package domain (needed for android/ios packaging)
package.domain = com.nuklear

# (str) Source code where the main.py live
source.dir = .

# (list) Source files to include (let empty to include all the files)
source.include_exts = py,png,jpg,kv,atlas,json

# (str) Application versioning
version = 1.0.0

# (list) Application requirements
# IMPORTANTE: NÃO usar pyjnius separado, já vem incluído.
# Removido 'android' pois é implícito no bootstrap.
requirements = python3,kivy,pillow,plyer

# (str) Supported orientation
orientation = portrait

# (bool) Indicate if the application should be fullscreen or not
fullscreen = 0

#
# Android specific
#

# (list) Permissions
android.permissions = INTERNET,CAMERA,WRITE_EXTERNAL_STORAGE,READ_EXTERNAL_STORAGE

# (int) Target Android API
android.api = 33

# (int) Minimum API
android.minapi = 21

# (int) Android NDK API to use
android.ndk_api = 21

# (bool) Automatically accept SDK license
android.accept_sdk_license = True

# (str) The Android arch to build for
# Usar só arm64-v8a para ser mais rápido no Colab
android.archs = arm64-v8a

# (bool) enables Android auto backup feature
android.allow_backup = True

# (str) Android app theme
android.apptheme = @android:style/Theme.NoTitleBar

# (str) Bootstrap to use for android builds
p4a.bootstrap = sdl2

# (str) python-for-android branch to use
# IMPORTANTE: usar develop para evitar bugs do master
p4a.branch = develop

[buildozer]

# (int) Log level (0 = error only, 1 = info, 2 = debug (with command output))
log_level = 2

# (int) Display warning if buildozer is run as root (0 = False, 1 = True)
warn_on_root = 0
